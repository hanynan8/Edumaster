// ═══════════════════════════════════════════════
//  app/(pages)/courses/[id]/page.jsx
//
//  اليوم 13: صفحة تفاصيل دورة عامة. بتجيب:
//    - GET /api/courses/[id]           → بيانات الدورة (404 لو draft/مش موجود)
//    - GET /api/courses/[id]/sections  → شجرة الأقسام/الدروس (السيرفر بيقرر
//      يبعت رابط الفيديو الحقيقي ولا لأ حسب الوصول — شوف الـ route)
//    - GET /api/enrollments?course=id  → { enrolled, hasAccess, accessSource }
//      (لو مسجل دخول أصلاً)
//
//  الفيديو نفسه مقفول (بيظهر قفل بدل الزرار) لأي درس مش preview ومفيش
//  videoUrl راجع من السيرفر — يعني الطالب لسه مالوش وصول. الزرار "اشترك"
//  بيستخدم POST /api/enrollments (دورات مجانية، أو دورة مدفوع لو عنده
//  membership نشطة بتغطيه — Phase 2 اليوم 18-19/22؛ غير كده بيوجّه لرسالة
//  "قريبًا" لحد ما يتبني مسار الدفع المباشر).
//
//  🔒 Phase 2 — اليوم 22: عضو membership نشطة بيشوف المحتوى مفتوح فورًا
//  (hasAccess=true) حتى لو مالوش سجل Enrollment صريح لسه — بنسجّله تلقائيًا
//  وبهدوء في الخلفية أول ما نكتشف كده (عشان تتبع التقدّم يشتغل من غير ما
//  نطلب منه يضغط زرار).
// ═══════════════════════════════════════════════
"use client";

import { useEffect, useRef, useState, use as usePromise } from "react";
import { useSession } from "next-auth/react";
import Image from "next/image";
import Link from "next/link";
import { useLanguage } from "@/contexts/LanguageContext";
import AuthModal from "@/app/components/auth/authModel";
import PaymentGatewayModal from "@/app/components/payments/PaymentGatewayModal";
import { getPriceForCurrency, formatPrice } from "@/app/lib/currency";
import CourseAnnouncements from "@/app/components/CourseAnnouncements";
import CourseMeetingBanner from "@/app/components/CourseMeetingBanner";
import LessonComments from "@/app/components/LessonComments";
import {
  Lock, PlayCircle, FileText, FileType2, HelpCircle, ChevronDown,
  BookOpen, CheckCircle2, Loader, ArrowRight, ArrowLeft,
} from "lucide-react";

const LESSON_ICONS = { video: PlayCircle, pdf: FileType2, text: FileText, quiz: HelpCircle };

const STRINGS = {
  ar: {
    back: "كل الدورات",
    by: "بواسطة",
    free: "مجاني",
    levels: { beginner: "مبتدئ", intermediate: "متوسط", advanced: "متقدم" },
    lessonsCount: (n) => `${n} درس`,
    studentsCount: (n) => `${n} طالب`,
    content: "محتوى الدورة",
    requirements: "المتطلبات",
    outcomes: "ماذا ستتعلم",
    enroll: "اشترك في الدورة",
    buyNow: "اشترِ الآن",
    enrolling: "جارِ التسجيل...",
    redirecting: "جارِ التحويل إلى صفحة الدفع...",
    enrolled: "أنت مسجّل في هذه الدورة",
    includedInMembership: "متضمّن في اشتراكك الحالي",
    loginToEnroll: "سجّل دخولك للاشتراك في الدورة",
    login: "تسجيل الدخول",
    paymentSoon: "الدفع الإلكتروني غير متاح حاليًا — تواصل مع الإدارة للتسجيل اليدوي",
    paymentGatewayError: "تعذّر بدء عملية الدفع، حاول مرة أخرى",
    ownCourse: "هذه دورتك — يمكنك إدارة محتواها من لوحة المدرّس",
    manage: "إدارة المحتوى",
    locked: "مغلق",
    preview: "معاينة مجانية",
    loading: "جارِ التحميل...",
    error: "تعذّر تحميل الدورة",
    noSections: "لا يوجد محتوى مضاف لهذه الدورة بعد",
    lockedHint: "اشترك في الدورة لفتح هذا الدرس",
    takeQuiz: "افتح الاختبار",
    quizType: "اختبار",
    quizzesTitle: "اختبارات الدورة",
    assignmentsTitle: "واجبات الدورة",
    openAssignment: "افتح الواجب",
    myGradesLink: "عرض درجاتك ونتائجك",
    completed: "تم إكمال هذا الدرس",
    progressTitle: "نسبة إكمال الدورة",
    levelTestTitle: "اختبر مستواك في اللغة",
    levelTestDesc: "قبل أن تبدأ، اختبر مستواك الحالي في اللغة لتعرف من أين تبدأ بالضبط.",
    levelTestCta: "ابدأ الاختبار",
    levelTestOpenNewTab: "فتح الاختبار في صفحة جديدة",
  },
  en: {
    back: "All Courses",
    by: "by",
    free: "Free",
    levels: { beginner: "Beginner", intermediate: "Intermediate", advanced: "Advanced" },
    lessonsCount: (n) => `${n} lessons`,
    studentsCount: (n) => `${n} students`,
    content: "Course Content",
    requirements: "Requirements",
    outcomes: "What you'll learn",
    enroll: "Enroll in this course",
    buyNow: "Buy Now",
    enrolling: "Enrolling...",
    redirecting: "Redirecting to payment...",
    enrolled: "You're enrolled in this course",
    includedInMembership: "Included in your current membership",
    loginToEnroll: "Log in to enroll in this course",
    login: "Log In",
    paymentSoon: "Online payment isn't available right now — contact us to enroll manually",
    paymentGatewayError: "Couldn't start the payment, please try again",
    ownCourse: "This is your course — manage its content from the teacher dashboard",
    manage: "Manage Content",
    locked: "Locked",
    preview: "Free Preview",
    loading: "Loading...",
    error: "Couldn't load this course",
    noSections: "No content has been added to this course yet",
    lockedHint: "Enroll in the course to unlock this lesson",
    takeQuiz: "Open quiz",
    quizType: "Quiz",
    quizzesTitle: "Course Quizzes",
    assignmentsTitle: "Course Assignments",
    openAssignment: "Open assignment",
    myGradesLink: "View your grades & results",
    completed: "You completed this lesson",
    progressTitle: "Course completion",
    levelTestTitle: "Test Your Level",
    levelTestDesc: "Before you start, take a quick test to see your current level in this language.",
    levelTestCta: "Start the test",
    levelTestOpenNewTab: "Open the test in a new tab",
  },
};

function formatDuration(seconds) {
  const total = Number(seconds) || 0;
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}

// بيستخدم مكتبة player.js (اللي Bunny Stream بتدعمها رسميًا فوق الـ iframe
// بتاعها، وبرضو بتشتغل مع يوتيوب لأن فيها adapter مبني فيها ليه) عشان
// نعرف نمسك حدث "ended" الحقيقي (وصول الفيديو لآخره) — من غير المكتبة دي
// مفيش وسيلة نوصل لأحداث الفيديو جوه iframe من دومين تاني (Bunny/YouTube).
function VideoEmbed({ lesson, onEnded }) {
  const iframeRef = useRef(null);
  const endedFiredRef = useRef(false);

  // كل درس فيديو جديد يفضل يقدر يبعت "ended" تاني من الأول
  useEffect(() => {
    endedFiredRef.current = false;
  }, [lesson.id]);

  useEffect(() => {
    if (!lesson.videoUrl) return;
    let cancelled = false;

    function attach() {
      if (cancelled || !iframeRef.current || !window.playerjs) return;
      const player = new window.playerjs.Player(iframeRef.current);
      player.on("ready", () => {
        player.on("ended", () => {
          if (!endedFiredRef.current) {
            endedFiredRef.current = true;
            onEnded?.();
          }
        });
      });
    }

    if (window.playerjs) {
      attach();
    } else {
      let script = document.getElementById("playerjs-cdn-script");
      if (!script) {
        script = document.createElement("script");
        script.id = "playerjs-cdn-script";
        script.src = "https://assets.mediadelivery.net/playerjs/playerjs-latest.min.js";
        script.async = true;
        document.body.appendChild(script);
      }
      script.addEventListener("load", attach);
    }

    return () => {
      cancelled = true;
    };
  }, [lesson.videoUrl, lesson.id, onEnded]);

  if (!lesson.videoUrl) return null;

  let src;
  if (lesson.videoProvider === "youtube") {
    // يقبل رابط youtube كامل أو ID مباشرة. enablejsapi=1 مطلوب عشان
    // player.js يقدر يكلّم الـ iframe عن طريق postMessage.
    const match = lesson.videoUrl.match(/(?:v=|youtu\.be\/|embed\/)([a-zA-Z0-9_-]{6,})/);
    const videoId = match ? match[1] : lesson.videoUrl;
    src = `https://www.youtube.com/embed/${videoId}?enablejsapi=1`;
  } else {
    // فيديوهات Bunny Stream: buildStreamPlaybackUrl في app/lib/bunny.js
    // بيرجّع رابط صفحة iframe embed كاملة، مش ملف فيديو مباشر — لازم
    // يتحط جوه <iframe> مش جوه <video src=...>.
    src = lesson.videoUrl;
  }

  return (
    <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-black">
      <iframe
        ref={iframeRef}
        src={src}
        className="absolute inset-0 w-full h-full"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
      />
    </div>
  );
}

function LessonRow({ lesson, t, isOpen, onToggle, hasAccess, isCompleted, onMarkComplete }) {
  const Icon = LESSON_ICONS[lesson.type] || FileText;

  // تسجيل تقدّم الطالب أوتوماتيك:
  // - نص/PDF: بمجرد ما الطالب يفتح الدرس (isOpen بيتحول true).
  // - فيديو: عند وصوله لآخره (VideoEmbed بينده onEnded تحت، مش هنا).
  useEffect(() => {
    if (!hasAccess || isCompleted) return;
    if (isOpen && (lesson.type === "text" || lesson.type === "pdf")) {
      onMarkComplete();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, lesson.type, hasAccess, isCompleted]);

  // Phase 4 — اليوم 42: درس النوع "quiz" مالوش videoUrl/textContent/fileUrl
  // خالص — محتواه الفعلي (الأسئلة) في مستند Quiz منفصل ومحمي بفحصه الخاص
  // (شوف /api/quizzes/[id]). هنا بس بنقرر نعرض لينك يودّي لصفحة الحل ولا
  // قفل، حسب وصول الطالب لهذه الدورة (hasAccess) أو preview.
  if (lesson.type === "quiz") {
    const canOpenQuiz = Boolean(lesson.quiz) && (lesson.isPreview || hasAccess);
    return (
      <div className="border-b border-gray-100 last:border-0">
        {canOpenQuiz ? (
          <Link
            href={`/student/quizzes/${lesson.quiz}`}
            className="w-full flex items-center gap-3 px-4 sm:px-5 py-3.5 text-start hover:bg-gray-50 transition-colors"
          >
            <Icon size={17} className="text-[#003A91] shrink-0" />
            <span className="flex-1 text-sm font-medium text-gray-700 truncate">{lesson.title}</span>
            {lesson.isPreview && (
              <span className="text-[10px] font-bold bg-green-50 text-green-600 px-2 py-0.5 rounded-full shrink-0">
                {t.preview}
              </span>
            )}
            <span className="text-xs font-semibold text-[#003A91] shrink-0">{t.takeQuiz}</span>
          </Link>
        ) : (
          <div className="w-full flex items-center gap-3 px-4 sm:px-5 py-3.5 opacity-70 cursor-not-allowed">
            <Lock size={16} className="text-gray-400 shrink-0" />
            <span className="flex-1 text-sm font-medium text-gray-700 truncate">{lesson.title}</span>
          </div>
        )}
        {!canOpenQuiz && (
          <div className="px-4 sm:px-5 pb-3 -mt-1">
            <p className="text-xs text-gray-400">{t.lockedHint}</p>
          </div>
        )}
      </div>
    );
  }

  const unlocked = Boolean(lesson.videoUrl || lesson.textContent || lesson.fileUrl) || lesson.isPreview;
  const canOpen = unlocked && (lesson.type === "video" ? Boolean(lesson.videoUrl) : true);

  return (
    <div className="border-b border-gray-100 last:border-0">
      <button
        onClick={() => canOpen && onToggle(lesson.id)}
        className={`w-full flex items-center gap-3 px-4 sm:px-5 py-3.5 text-start transition-colors ${
          canOpen ? "hover:bg-gray-50 cursor-pointer" : "cursor-not-allowed opacity-70"
        }`}
      >
        {canOpen ? (
          isCompleted ? (
            <CheckCircle2 size={17} className="text-green-500 shrink-0" />
          ) : (
            <Icon size={17} className="text-[#003A91] shrink-0" />
          )
        ) : (
          <Lock size={16} className="text-gray-400 shrink-0" />
        )}
        <span className="flex-1 text-sm font-medium text-gray-700 truncate">{lesson.title}</span>
        {lesson.isPreview && (
          <span className="text-[10px] font-bold bg-green-50 text-green-600 px-2 py-0.5 rounded-full shrink-0">
            {t.preview}
          </span>
        )}
        {lesson.type === "video" && lesson.durationSeconds > 0 && (
          <span className="text-xs text-gray-400 shrink-0">{formatDuration(lesson.durationSeconds)}</span>
        )}
        {canOpen && (
          <ChevronDown size={16} className={`text-gray-400 shrink-0 transition-transform ${isOpen ? "rotate-180" : ""}`} />
        )}
      </button>

      {isOpen && canOpen && (
        <div className="px-4 sm:px-5 pb-4">
          {lesson.type === "video" && (
            <VideoEmbed
              lesson={lesson}
              onEnded={() => {
                if (hasAccess && !isCompleted) onMarkComplete();
              }}
            />
          )}
          {lesson.type === "text" && lesson.textContent && (
            <div className="prose prose-sm max-w-none text-gray-600 bg-gray-50 rounded-xl p-4">
              {lesson.textContent}
            </div>
          )}
          {lesson.type === "pdf" && lesson.fileUrl && (
            <a href={lesson.fileUrl} target="_blank" rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-sm font-semibold text-[#003A91] hover:underline">
              <FileType2 size={15} /> {lesson.title}
            </a>
          )}
          {/* تسجيل تقدّم الطالب بقى تلقائي بالكامل (نص/PDF عند الفتح،
              فيديو عند وصوله لآخره) — هنا بنعرض بس تأكيد بصري لو الدرس
              اتسجل مكتمل، مفيش زرار يدوي. */}
          {hasAccess && isCompleted && (
            <div className="flex items-center gap-1.5 text-xs font-semibold text-green-600 mt-3">
              <CheckCircle2 size={14} /> {t.completed}
            </div>
          )}

          {/* Phase 6 — اليوم 48-49: نقاش الدرس لطالب عنده وصول فعلي بس
              (مش لزائر preview — نفس شرط /api/lessons/[id]/comments). */}
          {hasAccess && <LessonComments lessonId={lesson.id} />}
        </div>
      )}

      {!canOpen && (
        <div className="px-4 sm:px-5 pb-3 -mt-1">
          <p className="text-xs text-gray-400">{t.lockedHint}</p>
        </div>
      )}
    </div>
  );
}

// كل الدورات دلوقتي حقيقية (Course model) — مفيش تفرقة "admin-" تاني.
// الصفحة بتجيب الدورة من /api/courses/[id] وتعرض النسخة اللغوية المناسبة
// من course.i18n حسب لغة الموقع الحالية.
// 🆕 اختبار "قيّم مستواك" (ClassMarker): iframe مباشر لصفحة بدء الاختبار.
// بنبعت بيانات الطالب (لو مسجّل دخول) عن طريق باراميترات ClassMarker
// الرسمية (cm_fn/cm_e/cm_user_id) عشان نتائجه تتربط باسمه/إيميله تلقائيًا
// من غير ما يكتبهم يدوي — شوف ClassMarker Integration Guide.
function LevelTestSection({ quizId, session, t }) {
  const params = new URLSearchParams({ iframe: "1" });
  const name = session?.user?.name;
  const email = session?.user?.email;
  const userId = session?.user?.id;
  if (name) params.set("cm_fn", name);
  if (email) params.set("cm_e", email);
  if (userId) params.set("cm_user_id", String(userId).slice(0, 100));

  const src = `https://www.classmarker.com/online-test/start/?quiz=${encodeURIComponent(quizId)}&${params.toString()}`;
  const directLink = `https://www.classmarker.com/online-test/start/?quiz=${encodeURIComponent(quizId)}`;

  return (
    <div className="mt-8 sm:mt-10 bg-white rounded-2xl border border-gray-100 p-5 sm:p-6">
      <h2 className="text-lg font-semibold text-gray-800 mb-1.5">{t.levelTestTitle}</h2>
      <p className="text-sm text-gray-500 mb-4">{t.levelTestDesc}</p>
      <div className="w-full rounded-xl overflow-hidden border border-gray-100" style={{ height: 700 }}>
        <iframe
          src={src}
          title={t.levelTestTitle}
          className="w-full h-full"
          frameBorder="0"
        />
      </div>
      <a
        href={directLink}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-block mt-3 text-xs font-semibold text-[#003A91] hover:underline"
      >
        {t.levelTestOpenNewTab}
      </a>
    </div>
  );
}

export default function CourseDetailPage({ params }) {
  const { id } = usePromise(params);
  return <RealCourseDetail id={id} />;
}

function RealCourseDetail({ id }) {
  const { language, isRTL } = useLanguage();
  const t = STRINGS[language] || STRINGS.en;
  const { data: session, status: sessionStatus } = useSession();
  const BackArrow = isRTL ? ArrowLeft : ArrowRight;

  const [course, setCourse] = useState(null);
  const [sections, setSections] = useState(null);
  const [enrollment, setEnrollment] = useState(null); // { enrolled, enrollment } | null (لسه بيحمّل) | false (زائر)
  const [error, setError] = useState("");
  const [notFound, setNotFound] = useState(false);
  const [openLessonId, setOpenLessonId] = useState(null);
  const [enrolling, setEnrolling] = useState(false);
  const [enrollError, setEnrollError] = useState("");
  // Phase 4 — اليوم 42: اختبارات وواجبات الدورة المنشورة، بتتعرض تحت المحتوى
  // (روابط مباشرة لصفحات الحل/التسليم للطالب المسجّل).
  const [quizzes, setQuizzes] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState("login");
  // 🆕 المستخدم ضغط "اشترِ الآن" لدورة مدفوع — بننتظر تأكيده في
  // PaymentGatewayModal قبل ما نبدأ checkout فعلي عند GetPayIn.
  const [showGatewayModal, setShowGatewayModal] = useState(false);
  // تتبع تقدّم الطالب: أي درس (فيديو/PDF/نص) بيتحدد "مكتمل" لما الطالب
  // يضغط الزرار داخل LessonRow — ده اللي فعليًا بيحسب في نسبة إكمال الدورة
  // (progressPercent)، شوف app/lib/progressHelpers.js.
  const [markingLessonId, setMarkingLessonId] = useState(null);

  async function loadAll() {
    try {
      const [courseRes, sectionsRes, quizzesRes, assignmentsRes] = await Promise.all([
        fetch(`/api/courses/${id}`),
        fetch(`/api/courses/${id}/sections`),
        fetch(`/api/quizzes?course=${id}`),
        fetch(`/api/assignments?course=${id}`),
      ]);
      if (courseRes.status === 404) {
        setNotFound(true);
        return;
      }
      const courseData = await courseRes.json();
      const sectionsData = await sectionsRes.json();
      if (!courseRes.ok) throw new Error(courseData?.error || "error");
      setCourse(courseData);
      setSections(Array.isArray(sectionsData) ? sectionsData : []);
      if (quizzesRes.ok) {
        const quizzesData = await quizzesRes.json();
        setQuizzes(quizzesData.quizzes || []);
      }
      if (assignmentsRes.ok) {
        const assignmentsData = await assignmentsRes.json();
        setAssignments(assignmentsData.assignments || []);
      }
    } catch {
      setError(t.error);
    }
  }

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  // IDs الدروس المكتملة من enrollment.completedLessons — enrollment هنا
  // ممكن يبقى false (زائر) أو null (لسه بيحمّل) أو { enrolled, enrollment, ... }.
  const completedLessonIds = new Set(enrollment?.enrollment?.completedLessons || []);

  async function handleMarkComplete(lessonId) {
    if (markingLessonId === lessonId) return; // منع ضغطات/نداءات متكررة لنفس الدرس
    setMarkingLessonId(lessonId);
    try {
      const res = await fetch(`/api/lessons/${lessonId}/complete`, { method: "POST" });
      const data = await res.json();
      if (res.ok) {
        // نحدّث enrollment محليًا (completedLessons + progressPercent) من
        // غير ما نعمل reload كامل للصفحة — نفس شكل الـ object اللي بيرجع
        // من GET /api/enrollments?course=id.
        setEnrollment((prev) => {
          if (!prev || !prev.enrollment) return prev;
          const prevCompleted = prev.enrollment.completedLessons || [];
          const nextCompleted = prevCompleted.includes(lessonId)
            ? prevCompleted
            : [...prevCompleted, lessonId];
          return {
            ...prev,
            enrollment: {
              ...prev.enrollment,
              completedLessons: nextCompleted,
              progressPercent: data.progressPercent ?? prev.enrollment.progressPercent,
            },
          };
        });
      }
    } catch {
      // فشل الشبكة — نسيب الزرار زي ما هو، الطالب يقدر يحاول تاني
    } finally {
      setMarkingLessonId(null);
    }
  }

  // حالة الاشتراك بتتجاب لوحدها بعد ما نعرف فيه session ولا لأ
  useEffect(() => {
    if (sessionStatus === "loading") return;
    if (!session?.user) {
      setEnrollment(false);
      return;
    }
    fetch(`/api/enrollments?course=${id}`)
      .then((r) => (r.ok ? r.json() : { enrolled: false, hasAccess: false }))
      .then((data) => {
        setEnrollment(data);
        // 🔒 Phase 2 — اليوم 22: عنده وصول عن طريق membership لكن لسه مفيش
        // سجل Enrollment صريح — نسجّله بهدوء في الخلفية (من غير ما نستنى
        // ضغطة زرار) عشان تتبع التقدّم يبدأ يشتغل، والزرار يبقى badge
        // "متضمّن في اشتراكك" على طول بدل "اشترك".
        if (data.hasAccess && !data.enrolled && data.accessSource === "membership") {
          fetch("/api/enrollments", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ course: id }),
          })
            .then((r) => (r.ok ? r.json() : null))
            .then((res) => {
              if (res?.enrollment) setEnrollment({ enrolled: true, hasAccess: true, accessSource: "membership", enrollment: res.enrollment });
            })
            .catch(() => {});
        }
      })
      .catch(() => setEnrollment({ enrolled: false, hasAccess: false }));
  }, [id, session, sessionStatus]);

  // 🆕 Phase 3 — اليوم 27-28 + GetPayIn: دورة مدفوع (مش متاح مجانًا وعضويتنا
  // لو موجودة مش بتغطيه) → checkout عند GetPayIn (بعد تأكيد المستخدم في
  // PaymentGatewayModal) بدل POST /api/enrollments مباشرة. لو
  // enrollment.hasAccess=true (عن طريق membership) الزرار أصلاً بيظهر
  // كـ "متضمّن في اشتراكك" مش "اشتري" (شوف isViaMembership تحت)، فمفيش
  // احتمال يدفع لحاجة عنده وصول ليها بالفعل.
  async function handleBuyConfirm() {
    setShowGatewayModal(false);
    setEnrollError("");
    setEnrolling(true);
    try {
      const res = await fetch("/api/payments/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "course", id, language }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.redirectUrl) {
        if (data.error === "cannot_enroll_own_course") setEnrollError(t.ownCourse);
        else if (data.error === "payment_gateway_not_configured") setEnrollError(t.paymentSoon);
        else setEnrollError(t.paymentGatewayError);
        setEnrolling(false);
        return;
      }
      // بنسيب enrolling=true عشان الزرار يفضل معطّل لحد ما التحويل يحصل
      window.location.href = data.redirectUrl;
    } catch {
      setEnrollError(t.paymentGatewayError);
      setEnrolling(false);
    }
  }

  function openGatewayModal() {
    setEnrollError("");
    setShowGatewayModal(true);
  }

  async function handleEnroll() {
    // دورة مدفوع فعليًا (isFree=false) والمستخدم مالوش وصول عن طريق
    // membership أصلاً → نفتح مودال تأكيد الدفع بدل محاولة enroll مباشر
    // هيرجع 402 أكيد.
    const coursePriceInfo = getPriceForCurrency(course.prices, language);
    if (!course.isFree && coursePriceInfo.amount > 0) {
      return openGatewayModal();
    }

    setEnrollError("");
    setEnrolling(true);
    try {
      const res = await fetch("/api/enrollments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ course: id }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        if (data.error === "payment_required") {
          // fallback نادر: السيرفر شايف إنه محتاج دفع رغم كده (مثلاً السعر
          // اتغيّر بعد ما الصفحة اتحملت) — نفتح مودال اختيار بوابة الدفع
          // بدل ما نوقف هنا.
          setEnrolling(false);
          return openGatewayModal();
        } else if (data.error === "cannot_enroll_own_course") {
          setEnrollError(t.ownCourse);
        } else {
          setEnrollError(t.error);
        }
        return;
      }
      setEnrollment({ enrolled: true, hasAccess: true, accessSource: data.enrollment?.source === "membership" ? "membership" : "enrollment", enrollment: data.enrollment });
      loadAll(); // يحدّث sections عشان يفتح المحتوى المقفول فورًا
    } catch {
      setEnrollError(t.error);
    } finally {
      setEnrolling(false);
    }
  }

  if (notFound) {
    return (
      <div className="max-w-2xl mx-auto px-6 py-24 text-center">
        <h1 className="text-2xl font-semibold text-gray-700 mb-2">404</h1>
        <p className="text-gray-400 mb-6">{t.error}</p>
        <Link href="/courses" className="text-[#003A91] font-semibold hover:underline">{t.back}</Link>
      </div>
    );
  }

  if (error) {
    return <div className="max-w-2xl mx-auto px-6 py-24 text-center text-red-500">{error}</div>;
  }

  if (!course || !sections) {
    return (
      <div className="flex flex-col items-center justify-center gap-4 py-32">
        <span aria-hidden="true" className="block" style={{ height: 32 }} />
        <span className="text-xs font-bold tracking-[0.2em] uppercase text-gray-400">{t.loading}</span>
      </div>
    );
  }

  const isOwner = session?.user?.id && course.teacher === session.user.id;
  const coursePriceInfo = getPriceForCurrency(course.prices, language);
  // 🆕 كورس إسباني تحت Language → زرار اختبار المستوى (/spanish-test) جمب السعر
  const isSpanishCourse = course.categorySlug === "language" && course.language === "es";
  const isEnrolled = Boolean(enrollment && enrollment.enrolled);
  const isViaMembership = isEnrolled && enrollment?.accessSource === "membership";

  // 🆕 النسخة المترجمة المناسبة للغة الموقع الحالية — لو مش متوفرة، بترجع
  // للحقول الأساسية بتاعة الدورة (نسخة لغة الدورة الافتراضية).
  const i18nEntry = course.i18n?.[language] || course.i18n?.en || null;
  const categoryI18nEntry = course.categoryI18n?.[language] || course.categoryI18n?.en || null;
  const loc = {
    title: i18nEntry?.title || course.title,
    shortDescription: i18nEntry?.shortDescription || course.shortDescription,
    description: i18nEntry?.description || course.description,
    categoryName: categoryI18nEntry?.name || course.categoryName,
    requirements: i18nEntry?.requirements?.length ? i18nEntry.requirements : course.requirements,
    outcomes: i18nEntry?.outcomes?.length ? i18nEntry.outcomes : course.outcomes,
    certification: i18nEntry?.certification?.name ? i18nEntry.certification : null,
  };

  return (
    <div dir={isRTL ? "rtl" : "ltr"} className="min-h-screen bg-[#f7f7f7]">
      {/* Hero */}
      <section className="relative bg-[#0a0a0a] text-white overflow-hidden">
        {/* 🆕 خلفية الهيرو بقت صورة الدورة نفسها (لو موجودة) مكبّرة ومضبّبة
            شوية، مع طبقة تظليل غامقة فوقها عشان النص يفضل واضح ومقروء. لو
            مفيش thumbnail أصلاً بيرجع لنفس الخلفية السودا القديمة. */}
        {course.thumbnail && (
          <div className="absolute inset-0" aria-hidden="true">
            <Image
              src={course.thumbnail}
              alt=""
              fill
              unoptimized
              className="object-cover scale-110 blur-md"
            />
            <div className="absolute inset-0 bg-black/50" />
          </div>
        )}
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 py-10 sm:py-14">
          <Link href="/courses" className="inline-flex items-center gap-1.5 text-sm text-gray-300 hover:text-white mb-6">
            <BackArrow size={15} /> {t.back}
          </Link>

          <div className="grid lg:grid-cols-3 gap-8 items-start">
            <div className="lg:col-span-2">
              {loc.categoryName && (
                <span className="inline-block text-[11px] font-bold uppercase tracking-widest text-[#003A91] bg-white/10 px-3 py-1 rounded-full mb-4">
                  {loc.categoryName}
                </span>
              )}
              <h1 className="text-2xl sm:text-4xl font-semibold tracking-tight leading-tight mb-3">{loc.title}</h1>
              {loc.shortDescription && (
                <p className="text-gray-300 text-sm sm:text-base leading-relaxed mb-5">{loc.shortDescription}</p>
              )}
            </div>


            <div className="bg-white text-[#0a0a0a] rounded-2xl overflow-hidden shadow-2xl">
              <div className="relative h-44 bg-gray-100">
                {course.thumbnail ? (
                  <Image src={course.thumbnail} alt={loc.title} fill unoptimized className="object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-gray-300"><BookOpen size={40} /></div>
                )}
              </div>
              <div className="p-5">
                <div className="flex items-center justify-between gap-3 mb-4">
                  <p className="text-2xl font-black">
                    {course.isFree ? t.free : formatPrice(coursePriceInfo.amount, coursePriceInfo.currency, language)}
                  </p>
                  {isSpanishCourse && (
                    <Link
                      href="/spanish-test"
                      target="_blank"
                      className="inline-flex items-center border border-[#003A91]/30 text-[#003A91] text-xs font-bold px-3 py-2 rounded-lg hover:bg-[#003A91] hover:text-white transition-colors"
                    >
                      {t.levelTestTitle}
                    </Link>
                  )}
                </div>

                {isOwner ? (
                  <Link href={`/teacher/courses/${course.id}`}
                    className="block w-full text-center bg-[#0a0a0a] text-white font-bold py-3 rounded-xl hover:opacity-90 transition-opacity">
                    {t.manage}
                  </Link>
                ) : isEnrolled ? (
                  <div className="flex items-center justify-center gap-2 bg-green-50 text-green-700 font-bold py-3 rounded-xl">
                    <CheckCircle2 size={17} /> {isViaMembership ? t.includedInMembership : t.enrolled}
                  </div>
                ) : enrollment === false && sessionStatus !== "loading" ? (
                  <button
                    onClick={() => { setAuthMode("login"); setShowAuthModal(true); }}
                    className="w-full bg-[#003A91] text-white font-bold py-3 rounded-xl hover:opacity-90 transition-opacity"
                  >
                    {t.login}
                  </button>
                ) : (
                  <button
                    onClick={handleEnroll}
                    disabled={enrolling || enrollment === null}
                    className="w-full bg-[#003A91] text-white font-bold py-3 rounded-xl hover:opacity-90 transition-opacity disabled:opacity-60"
                  >
                    {enrolling
                      ? (!course.isFree && coursePriceInfo.amount > 0 ? t.redirecting : t.enrolling)
                      : (!course.isFree && coursePriceInfo.amount > 0 ? t.buyNow : t.enroll)}
                  </button>
                )}
                {enrollError && <p className="text-xs text-red-500 mt-3 text-center">{enrollError}</p>}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Body */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-10 sm:py-14">
        {/* 🆕 بانر "محاضرة النهاردة" — بيظهر بس لصاحب الدورة أو طالب مسجّل
            فعليًا (نفس شرط GET /api/courses/[id]/meetings)، وبيتخفي تلقائيًا
            لو مفيش محاضرة شغالة/قريبة (شوف CourseMeetingBanner). */}
        {(isOwner || isEnrolled) && (
          <div className="mb-6">
            <CourseMeetingBanner courseId={id} />
          </div>
        )}
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            {loc.description && (
              <div className="bg-white rounded-2xl border border-gray-100 p-5 sm:p-6">
                <p className="text-sm sm:text-[15px] text-gray-600 leading-relaxed whitespace-pre-line">{loc.description}</p>
              </div>
            )}

            <div>
              <h2 className="text-lg font-semibold text-gray-800 mb-4">{t.content}</h2>
              <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
                {sections.length === 0 && (
                  <p className="text-sm text-gray-400 text-center py-10">{t.noSections}</p>
                )}
                {sections.map((section) => (
                  <div key={section.id} className="border-b border-gray-100 last:border-0">
                    <div className="px-4 sm:px-5 py-3 bg-gray-50/70">
                      <h3 className="text-sm font-semibold text-gray-700">{section.title}</h3>
                    </div>
                    {section.lessons.map((lesson) => (
                      <LessonRow
                        key={lesson.id}
                        lesson={lesson}
                        t={t}
                        isOpen={openLessonId === lesson.id}
                        onToggle={(lid) => setOpenLessonId((prev) => (prev === lid ? null : lid))}
                        hasAccess={isOwner || isEnrolled}
                        isCompleted={completedLessonIds.has(lesson.id)}
                        onMarkComplete={() => handleMarkComplete(lesson.id)}
                      />
                    ))}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {/* نسبة إكمال الدورة — بتتحسب سيرفر-سايد في
                recomputeEnrollmentProgress (دروس مكتملة + اختبارات منجوحة)،
                هنا بس بنعرض القيمة الجاهزة من enrollment.progressPercent. */}
            {isEnrolled && !isOwner && (
              <div className="bg-white rounded-2xl border border-gray-100 p-5">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-semibold text-gray-800">{t.progressTitle}</h3>
                  <span className="text-sm font-black text-[#003A91]">
                    {enrollment?.enrollment?.progressPercent ?? 0}%
                  </span>
                </div>
                <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#003A91] rounded-full transition-all"
                    style={{ width: `${enrollment?.enrollment?.progressPercent ?? 0}%` }}
                  />
                </div>
              </div>
            )}

            {/* Phase 6 — اليوم 46-47: إعلانات الدورة لصاحب الدورة/أدمن أو
                طالب مسجّل فعليًا — نفس شرط الوصول اللي الـ API بيفرضه. */}
            {(isOwner || isEnrolled) && <CourseAnnouncements courseId={id} />}

            {/* 🔧 كان الشرط هنا isEnrolled بس — لكن enroll في دورة متاح لأي
                role (مفيش قيد في checkout/enroll API)، فمدرس أو أدمن ممكن
                يبقوا isEnrolled=true. الروابط الجاية (quizzes/assignments/
                grades) كلها تحت /student، والـ middleware بقى يرفض أي role
                غير student من دخولها — فضفنا شرط role === "student" هنا
                عشان السكشن ده يظهر بس لمين فعلاً هيقدر يفتح الروابط. */}
            {isEnrolled && session?.user?.role === "student" && (quizzes.length > 0 || assignments.length > 0) && (
              <div className="bg-white rounded-2xl border border-gray-100 p-5">
                {quizzes.length > 0 && (
                  <div className="mb-4">
                    <h3 className="text-sm font-semibold text-gray-800 mb-3">{t.quizzesTitle}</h3>
                    <ul className="space-y-2">
                      {quizzes.map((q) => (
                        <li key={q.id}>
                          <Link
                            href={`/student/quizzes/${q.id}`}
                            className="flex items-center gap-2 text-sm text-gray-600 hover:text-[#003A91] transition-colors"
                          >
                            <HelpCircle size={14} className="text-[#003A91] shrink-0" />
                            <span className="truncate flex-1">{q.title}</span>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {assignments.length > 0 && (
                  <div>
                    <h3 className="text-sm font-semibold text-gray-800 mb-3">{t.assignmentsTitle}</h3>
                    <ul className="space-y-2">
                      {assignments.map((a) => (
                        <li key={a.id}>
                          <Link
                            href={`/student/assignments/${a.id}`}
                            className="flex items-center gap-2 text-sm text-gray-600 hover:text-[#003A91] transition-colors"
                          >
                            <FileText size={14} className="text-[#003A91] shrink-0" />
                            <span className="truncate flex-1">{a.title}</span>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                <Link
                  href="/student/grades"
                  className="block text-center text-xs font-semibold text-[#003A91] hover:underline mt-4 pt-4 border-t border-gray-100"
                >
                  {t.myGradesLink}
                </Link>
              </div>
            )}

            {loc.outcomes?.length > 0 && (
              <div className="bg-white rounded-2xl border border-gray-100 p-5">
                <h3 className="text-sm font-semibold text-gray-800 mb-3">{t.outcomes}</h3>
                <ul className="space-y-2">
                  {loc.outcomes.map((o, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-gray-600">
                      <CheckCircle2 size={15} className="text-[#003A91] shrink-0 mt-0.5" /> {o}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {loc.requirements?.length > 0 && (
              <div className="bg-white rounded-2xl border border-gray-100 p-5">
                <h3 className="text-sm font-semibold text-gray-800 mb-3">{t.requirements}</h3>
                <ul className="space-y-2 list-disc ps-5">
                  {loc.requirements.map((r, i) => (
                    <li key={i} className="text-sm text-gray-600">{r}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>

        {/* 🆕 اختبار "قيّم مستواك" (ClassMarker) — بيظهر بس لو:
            (1) الدورة تحت تصنيف "Language" فعليًا (categorySlug === "language"،
            زي ما ظاهر في فلتر التصنيفات في /courses)، و
            (2) المدرس/الإدارة حط classMarkerQuizId لهذه الدورة بالذات
            (كل دورة لغة عنده امتحان تحديد مستوى مختلف — إنجليزي مش زي
            إسباني مثلًا — فمش منطقي نستخدم نفس الـ quiz لكل دورات اللغة).
            ظاهر لأي زائر (مش لازم يكون مسجّل دخول أو مشترك) لأن الهدف إنه
            يساعده يقرر يبدأ الدورة منين قبل حتى ما يشترك. */}
        {course.categorySlug === "language" && course.classMarkerQuizId && !isSpanishCourse && (
          <LevelTestSection quizId={course.classMarkerQuizId} session={session} t={t} />
        )}
      </section>

      {showAuthModal && (
        <AuthModal
          mode={authMode}
          onClose={() => setShowAuthModal(false)}
          onSwitch={(next) => setAuthMode(next)}
        />
      )}

      {showGatewayModal  && (
        <PaymentGatewayModal
          amount={coursePriceInfo.amount}
          currency={coursePriceInfo.currency}
          disabled={enrolling}
          onClose={() => setShowGatewayModal(false)}
          onConfirm={handleBuyConfirm}
        />
      )}
    </div>
  );
}