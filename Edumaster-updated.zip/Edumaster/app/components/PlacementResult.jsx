"use client";

// app/components/PlacementResult.jsx
//
// عرض نتيجة اختبار تحديد المستوى (إسباني): الدرجة من 100 + مستوى الطالب (حسب جدول
// المستويات) + الكورسات الموصى بها من كورسات الموقع (نفس مستوى الطالب وأعلى).
// بيُستخدم في صفحة الاختبار (اختبار مجاني) وفي صفحة نجاح الدفع (اختبار مدفوع).

import Link from "next/link";
import { getLevelByCode, getLevelByPercent } from "@/app/lib/placementLevels";
import { formatPrice } from "@/app/lib/currency";

const STRINGS = {
  ar: {
    yourScore: "درجتك",
    yourLevel: "مستواك",
    recommended: "كورسات مقترحة لك",
    recommendedHint: "كورسات من نفس مستواك وأعلى",
    bestFit: "الأنسب لك",
    free: "مجاني",
    none: "لا توجد كورسات منشورة حاليًا بهذا المستوى أو أعلى. تصفّح كل الكورسات:",
    browse: "تصفّح الكورسات",
    answered: "الأسئلة المُجاب عنها",
  },
  en: {
    yourScore: "Your score",
    yourLevel: "Your level",
    recommended: "Recommended courses for you",
    recommendedHint: "Courses at your level and above",
    bestFit: "Best fit",
    free: "Free",
    none: "There are no published courses at your level or above yet. Browse all courses:",
    browse: "Browse courses",
    answered: "Answered",
  },
  es: {
    yourScore: "Tu puntuación",
    yourLevel: "Tu nivel",
    recommended: "Cursos recomendados para ti",
    recommendedHint: "Cursos de tu nivel y superiores",
    bestFit: "Ideal para ti",
    free: "Gratis",
    none: "Aún no hay cursos publicados de tu nivel o superior. Explora todos los cursos:",
    browse: "Ver cursos",
    answered: "Respondidas",
  },
};

export default function PlacementResult({ result, language = "ar", children }) {
  const t = STRINGS[language] ?? STRINGS.en;
  const level = getLevelByCode(result?.level) || getLevelByPercent(result?.score);
  const desc = level.desc[language] ?? level.desc.en;
  const recommended = Array.isArray(result?.recommended) ? result.recommended : [];

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 sm:p-8 text-center space-y-5">
        <div className="grid sm:grid-cols-2 gap-3">
          <div className="bg-[#003A91]/5 rounded-xl py-5 px-3">
            <p className="text-xs text-gray-500 mb-1">{t.yourScore}</p>
            <p className="text-5xl font-black text-[#003A91]" dir="ltr">
              {result.score}
              <span className="text-lg font-bold text-gray-400"> / {result.maxScore}</span>
            </p>
          </div>
          <div className="bg-[#003A91] rounded-xl py-5 px-3">
            <p className="text-xs text-white/70 mb-1">{t.yourLevel}</p>
            <p className="text-5xl font-black text-white" dir="ltr">{level.code}</p>
          </div>
        </div>
        <p className="text-sm text-gray-600 leading-relaxed">{desc}</p>
        {Number.isFinite(result.answeredCount) && (
          <p className="text-[11px] text-gray-400">
            {t.answered}: {result.answeredCount}/{result.totalQuestions}
          </p>
        )}
        {children}
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 sm:p-8">
        <h2 className="text-lg font-semibold text-gray-900">{t.recommended}</h2>
        <p className="text-xs text-gray-400 mt-0.5 mb-4">{t.recommendedHint}</p>

        {recommended.length === 0 ? (
          <p className="text-sm text-gray-500">
            {t.none}{" "}
            <Link href="/courses" className="font-bold text-[#003A91] underline">
              {t.browse}
            </Link>
          </p>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {recommended.map((c) => (
              <Link
                key={c.id}
                href={`/courses/${c.id}`}
                className={`group block rounded-xl border overflow-hidden transition-shadow hover:shadow-md ${
                  c.isNextStep ? "border-[#003A91]" : "border-gray-100"
                }`}
              >
                {c.thumbnail ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={c.thumbnail} alt={c.title} className="w-full h-32 object-cover" />
                ) : (
                  <div className="w-full h-32 bg-[#003A91]/5 flex items-center justify-center text-3xl font-black text-[#003A91]/30" dir="ltr">
                    {c.levelCode}
                  </div>
                )}
                <div className="p-3.5 space-y-1.5">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-[#003A91]/10 text-[#003A91]" dir="ltr">
                      {c.levelCode}
                    </span>
                    {c.isNextStep && (
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-green-50 text-green-600">
                        {t.bestFit}
                      </span>
                    )}
                  </div>
                  <p className="text-sm font-semibold text-gray-900 group-hover:text-[#003A91] line-clamp-2">{c.title}</p>
                  {c.shortDescription && <p className="text-xs text-gray-500 line-clamp-2">{c.shortDescription}</p>}
                  <p className="text-sm font-bold text-gray-800">
                    {c.isFree || !c.price ? t.free : formatPrice(c.price, c.currency, language)}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
