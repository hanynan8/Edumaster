// app/api/courses/[id]/route.js
//
// GET: عام لو الكورس published، وإلا صاحب الكورس/أدمن بس (عشان مدرس تاني
// أو زائر ميشوفش كورس لسه draft). PUT/DELETE: صاحب الكورس أو أدمن بس.

import mongoose from "mongoose";
import { connectToMongo } from "@/app/lib/mongodb";
import { getCourseModel, getCategoryModel, getSectionModel, getLessonModel } from "@/app/lib/models";
import { requireSession, isOwnerOrAdmin } from "@/app/lib/rbac";
import { slugify, sanitizeCourseI18n, resolveCourseSubcategory } from "@/app/lib/courseHelpers";
import { resolveSecureStoredUrl } from "@/app/lib/bunny";
import { createNotification, getAdminUserIds } from "@/app/lib/notificationHelpers";
import { sanitizePrices, emptyPrices } from "@/app/lib/currency";

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  });
}

function serializeCourse(c) {
  return {
    id: c._id.toString(),
    title: c.title,
    slug: c.slug,
    shortDescription: c.shortDescription,
    description: c.description,
    thumbnail: resolveSecureStoredUrl(c.thumbnail),
    i18n: c.i18n instanceof Map ? Object.fromEntries(c.i18n) : c.i18n || {},
    durationLabel: c.durationLabel || "",
    category: c.category?._id ? c.category._id.toString() : c.category?.toString(),
    categoryName: c.category?.name,
    categorySlug: c.category?.slug || "",
    categoryI18n: c.category?.i18n instanceof Map ? Object.fromEntries(c.category.i18n) : c.category?.i18n || {},
    subcategory: c.subcategory?._id ? c.subcategory._id.toString() : c.subcategory?.toString() || null,
    subcategoryName: c.subcategory?.name || "",
    subcategorySlug: c.subcategory?.slug || "",
    subcategoryI18n: c.subcategory?.i18n instanceof Map ? Object.fromEntries(c.subcategory.i18n) : c.subcategory?.i18n || {},
    teacher: c.teacher?._id ? c.teacher._id.toString() : c.teacher?.toString(),
    teacherName: c.teacher?.name,
    level: c.level,
    language: c.language,
    prices: c.prices || { EGP: 0, USD: 0, EUR: 0 },
    isFree: c.isFree,
    requirements: c.requirements,
    outcomes: c.outcomes,
    tags: c.tags,
    classMarkerQuizId: c.classMarkerQuizId || "",
    status: c.status,
    studentsCount: c.studentsCount,
    ratingAverage: c.ratingAverage,
    ratingCount: c.ratingCount,
    totalDurationSeconds: c.totalDurationSeconds,
    totalLessonsCount: c.totalLessonsCount,
    createdAt: c.createdAt,
    updatedAt: c.updatedAt,
  };
}

// حقول مسموح للمدرس/الأدمن يعدّلوها. أي حقل تاني (teacher, studentsCount,
// ratingAverage, totalDurationSeconds...) محسوب/محمي ومش موجود في اللستة دي
// عن قصد — حتى لو اتبعت في الـ body بيتجاهل تمامًا.
const EDITABLE_FIELDS = [
  "title",
  "shortDescription",
  "description",
  "thumbnail",
  "durationLabel",
  "category",
  "subcategory",
  "level",
  "language",
  "prices",
  "isFree",
  "requirements",
  "outcomes",
  "tags",
  "classMarkerQuizId",
  "status",
];

// 🩹 FIX (باگ "مش بيتحذف"): بعض الكورسات ممكن تكون اتحطت في الداتابيز
// مباشرة (سكريبت/استيراد بيانات/تعديل يدوي في الكلستر) من غير ما تعدي على
// POST /api/courses، فبتفتقد حقول Mongoose بتحسبها تلقائي (totalDurationSeconds،
// totalLessonsCount، studentsCount...) — عشان كده بتظهر في الكارت بـ "NaN"
// أو قيم فاضية. المستند نفسه غالبًا سليم (_id عادي)، لكن أي عملية عليه لازم
// تفضل تشتغل عادي؛ الدالة دي مجرد نقطة مركزية لجيب الكورس مستخدمة في
// GET/PUT/DELETE عشان نضمن نفس السلوك في التلاتة.
async function findCourseFlexible(id) {
  const Course = getCourseModel();
  if (mongoose.Types.ObjectId.isValid(id)) {
    const found = await Course.findById(id);
    if (found) return found;
  }
  // fallback: لو الـ id مش شكل ObjectId عادي (مثلاً كورس اتحط يدوي بـ _id
  // نصي)، findById كان بيرفضه فورًا (invalid_id) قبل حتى ما يدوّر في
  // الداتابيز — فمفيش طريقة تاني تحذفه من الواجهة أبدًا. بندوّر هنا بالـ
  // driver الخام (من غير كاست Mongoose) عشان نلاقيه ونقدر نتعامل معاه.
  try {
    const raw = await Course.collection.findOne({ _id: id });
    return raw ? Course.hydrate(raw) : null;
  } catch {
    return null;
  }
}

async function loadCourse(id) {
  const course = await findCourseFlexible(id);
  if (!course) return null;
  getCategoryModel();
  return course.populate([
    { path: "category", select: "name slug i18n" },
    { path: "subcategory", select: "name slug i18n parent" },
    { path: "teacher", select: "name" },
  ]);
}

export async function GET(request, { params }) {
  try {
    const { id } = await params;
    await connectToMongo();
    const course = await loadCourse(id);
    if (!course) return jsonResponse({ error: "not_found" }, 404);

    if (course.status !== "published") {
      const auth = await requireSession();
      if (auth.response) return jsonResponse({ error: "not_found" }, 404); // مش هنسرّب وجود كورس draft
      if (!isOwnerOrAdmin(auth.session, course.teacher._id || course.teacher)) {
        return jsonResponse({ error: "not_found" }, 404);
      }
    }

    return jsonResponse(serializeCourse(course));
  } catch (err) {
    console.error("[/api/courses/[id]] GET error:", err);
    return jsonResponse({ error: "internal_error" }, 500);
  }
}

export async function PUT(request, { params }) {
  try {
    const { id } = await params;

    await connectToMongo();
    const Course = getCourseModel();
    const existing = await findCourseFlexible(id);
    if (!existing) return jsonResponse({ error: "not_found" }, 404);

    const auth = await requireSession();
    if (auth.response) return auth.response;
    const { session } = auth;
    if (!isOwnerOrAdmin(session, existing.teacher)) {
      return jsonResponse({ error: "forbidden" }, 403);
    }

    const body = await request.json().catch(() => null);
    if (!body || typeof body !== "object") return jsonResponse({ error: "invalid_body" }, 400);

    const updates = {};
    for (const field of EDITABLE_FIELDS) {
      if (body[field] === undefined) continue;
      updates[field] = body[field];
    }

    if (updates.title !== undefined) {
      updates.title = String(updates.title).trim();
      if (!updates.title) return jsonResponse({ error: "invalid_title" }, 400);
    }
    let Category; // 🆕 لو المدرس/الأدمن عدّل category و/أو subcategory
    if (updates.category !== undefined) {
      if (!mongoose.Types.ObjectId.isValid(updates.category)) {
        return jsonResponse({ error: "invalid_category" }, 400);
      }
      Category = getCategoryModel();
      const cat = await Category.findById(updates.category).lean();
      if (!cat) return jsonResponse({ error: "category_not_found" }, 404);
    }

    // 🆕 ساب-تصنيف حقيقي (اختياري) — لازم يكون تابع لنفس التصنيف الرئيسي
    // (الجديد لو اتغيّر، وإلا القديم المحفوظ على الكورس أصلًا). لو
    // subcategory تابع لتصنيف "Language"، بنعبّي course.language تلقائيًا
    // من الـ slug بتاعه (backward-compat).
    if (updates.subcategory !== undefined) {
      Category = Category || getCategoryModel();
      const effectiveCategoryId = updates.category !== undefined ? updates.category : existing.category;
      const subRes = await resolveCourseSubcategory(Category, { subcategory: updates.subcategory }, effectiveCategoryId);
      if (!subRes.ok) return jsonResponse({ error: subRes.error }, 400);
      updates.subcategory = subRes.id;
      if (subRes.autoLanguage) updates.language = subRes.autoLanguage;
    }
    if (updates.level !== undefined && !["beginner", "intermediate", "advanced"].includes(updates.level)) {
      return jsonResponse({ error: "invalid_level" }, 400);
    }
    if (updates.status !== undefined && !["draft", "pending", "published", "archived"].includes(updates.status)) {
      return jsonResponse({ error: "invalid_status" }, 400);
    }

    // 🔒 PRODUCT RULE: مدرس (مش أدمن) مينفعش "ينشر" كورس مباشرة. لو حاول
    // يحط status="published" — سواء كورس جديد لسه draft، أو كورس رجّعه
    // draft بعدين حب ينشره تاني — بنحوّل الطلب لـ "pending" (قيد المراجعة)
    // بدل ما ننفذه زي ما هو، وبنبعت إشعار لكل الأدمنز إن فيه كورس مستني
    // مراجعة. لو الكورس أصلاً published ومحدّش غيّر status (لسه published
    // في الـ body)، ده مش "نشر جديد" فمنعملش حاجة (تعديل عادي مش لازم
    // مراجعة تانية).
    let submittedForReview = false;
    if (
      updates.status === "published" &&
      existing.status !== "published" &&
      session.user.role !== "admin"
    ) {
      updates.status = "pending";
      submittedForReview = true;
    }
    if (updates.prices !== undefined) {
      updates.prices = sanitizePrices(updates.prices);
    }
    if (updates.isFree) {
      updates.prices = emptyPrices();
    }
    if (updates.shortDescription !== undefined) {
      updates.shortDescription = String(updates.shortDescription).slice(0, 300);
    }
    // 🆕 اختبار ClassMarker: تعقيم بسيط (مسافات زيادة + حد أقصى للطول).
    // فاضي = مفيش اختبار لهذا الكورس، ده سلوك طبيعي ومقصود.
    if (updates.classMarkerQuizId !== undefined) {
      updates.classMarkerQuizId = String(updates.classMarkerQuizId).trim().slice(0, 100);
    }
    // 🔒 لو المدرس عايز يغيّر الـ slug لازم يبقى فريد
    if (body.slug !== undefined) {
      const newSlug = slugify(body.slug);
      if (!newSlug) return jsonResponse({ error: "invalid_slug" }, 400);
      if (newSlug !== existing.slug) {
        const taken = await Course.exists({ slug: newSlug, _id: { $ne: existing._id } });
        if (taken) return jsonResponse({ error: "slug_taken" }, 409);
        updates.slug = newSlug;
      }
    }

    // 🆕 i18n بيتعامل معاه لوحده: بندمج اللغات الجايه في body.i18n مع اللي
    // موجودة بالفعل في الكورس (مش overwrite كامل)، عشان تحديث لغة واحدة بس
    // (مثلاً المدرس عدّل النسخة الإنجليزية بس) ميمسحش النسخ التانية.
    if (body.i18n !== undefined) {
      const incoming = sanitizeCourseI18n(body.i18n);
      const merged = existing.i18n instanceof Map ? new Map(existing.i18n) : new Map();
      for (const [lang, content] of Object.entries(incoming)) {
        merged.set(lang, content);
      }
      updates.i18n = merged;
    }

    Object.assign(existing, updates);

    // 🩹 FIX (باگ "الحفظ بيرجع نجاح بس القيمة مش بتفضل"): existing.save()
    // بيعتمد إن Mongoose قادر يـ diff نسخة المستند اللي اتحمّلت في الذاكرة
    // صح. بعض الكورسات (خصوصًا كورسات قديمة اتحطت في الداتابيز مباشرة أو
    // باستيراد بيانات — زي app/scripts/migrate-marketing-courses-to-real.js
    // اللي بيعمل insertOne بالـ driver الخام من غير ما يعدي على Mongoose
    // أصلًا) شكلها مش مطابق تمامًا للـ schema الحالي، فـ save() كان بيرجع
    // status 200 "ناجح" من غير ما يبعت فعليًا كل الحقول المتغيّرة لداتابيز
    // (فالـ classMarkerQuizId مثلًا بيختفي أول ما تعمل reload). نفس فئة
    // المشكلة اللي DELETE تحت معالجها بـ fallback للـ driver الخام.
    // findByIdAndUpdate بيبني أمر $set مباشر بالـ id بس (من غير أي اعتماد
    // على "نسخة" المستند اللي اتحمّلت قبل كده)، فبيضمن إن كل حقل في updates
    // يوصل فعليًا للداتابيز أيًا كان شكل المستند الأصلي.
    let populated;
    try {
      const updatedDoc = await Course.findByIdAndUpdate(
        existing._id,
        { $set: updates },
        { new: true, runValidators: true }
      );
      if (!updatedDoc) return jsonResponse({ error: "not_found" }, 404);
      populated = await updatedDoc.populate([
        { path: "category", select: "name slug i18n" },
        { path: "subcategory", select: "name slug i18n parent" },
        { path: "teacher", select: "name" },
      ]);
    } catch (updateErr) {
      // fallback بالـ driver الخام — لو الـ _id أو أي حقل شكله مش قياسي
      // بيرمي CastError مع findByIdAndUpdate (نفس فكرة fallback الحذف تحت).
      console.error("[/api/courses/[id]] PUT findByIdAndUpdate fallback triggered:", updateErr?.message);
      const rawUpdates = { ...updates };
      if (rawUpdates.category !== undefined && mongoose.Types.ObjectId.isValid(rawUpdates.category)) {
        rawUpdates.category = new mongoose.Types.ObjectId(rawUpdates.category);
      }
      if (rawUpdates.subcategory !== undefined && rawUpdates.subcategory && mongoose.Types.ObjectId.isValid(rawUpdates.subcategory)) {
        rawUpdates.subcategory = new mongoose.Types.ObjectId(rawUpdates.subcategory);
      }
      if (rawUpdates.i18n instanceof Map) {
        rawUpdates.i18n = Object.fromEntries(rawUpdates.i18n);
      }
      await Course.collection.updateOne({ _id: existing._id }, { $set: rawUpdates });
      populated = await loadCourse(existing._id);
      if (!populated) return jsonResponse({ error: "not_found" }, 404);
    }

    // 🆕 best-effort: مش لازم نستنى الإشعارات دي أو نفشل الطلب لو فشلت —
    // شوف تعليق notificationHelpers.js عن نفس المبدأ في certificateHelpers.js
    if (submittedForReview) {
      getAdminUserIds()
        .then((adminIds) =>
          Promise.all(
            adminIds.map((adminId) =>
              createNotification({
                user: adminId,
                type: "course_pending_review",
                title: "دورة جديدة بانتظار المراجعة",
                message: `المدرس "${populated.teacher?.name || ""}" طلب نشر الدورة "${populated.title}" — وهي بحاجة إلى مراجعتك.`,
                link: "/admin",
                course: populated._id,
              })
            )
          )
        )
        .catch((err) => console.error("[/api/courses/[id]] PUT notify admins error:", err));
    }

    return jsonResponse({ ...serializeCourse(populated), submittedForReview });
  } catch (err) {
    console.error("[/api/courses/[id]] PUT error:", err);
    return jsonResponse({ error: "internal_error" }, 500);
  }
}

export async function DELETE(request, { params }) {
  try {
    const { id } = await params;

    await connectToMongo();
    const Course = getCourseModel();
    const course = await findCourseFlexible(id);
    if (!course) return jsonResponse({ error: "not_found" }, 404);

    const auth = await requireSession();
    if (auth.response) return auth.response;
    if (!isOwnerOrAdmin(auth.session, course.teacher)) {
      return jsonResponse({ error: "forbidden" }, 403);
    }

    // 🔒 SECURITY / DATA SAFETY: منع حذف كورس فيه طلاب مسجلين فعلاً — الحذف
    // العادي هيمسح كل الأقسام/الدروس وممكن يبوّظ تجربة طلاب دافعين. لو محتاج
    // "يقفل" كورس فيه طلاب، يستخدم status=archived بدل الحذف الفعلي.
    // (Number(...) عشان كورسات قديمة/معطوبة ممكن يبقى studentsCount عندها
    // undefined بدل 0 — undefined > 0 لوحدها كانت هتفوت بأمان برضه، لكن
    // بنثبّتها صراحة عشان الفحص يبقى واضح.)
    const studentsCount = Number(course.studentsCount) || 0;
    if (studentsCount > 0) {
      return jsonResponse({ error: "course_has_students", studentsCount }, 409);
    }

    const Section = getSectionModel();
    const Lesson = getLessonModel();

    try {
      await Promise.all([
        Lesson.deleteMany({ course: course._id }),
        Section.deleteMany({ course: course._id }),
      ]);
      await course.deleteOne();
    } catch (deleteErr) {
      // 🩹 FIX: كورسات معطوبة (اتحطت يدوي في الداتابيز، مش عن طريق
      // التطبيق) ممكن يبقى فيها قيمة _id أو حقول تانية بشكل Mongoose مش
      // متوقعه (مثلاً _id مش ObjectId قياسي) — في الحالة دي course.deleteOne()
      // بيحاول يعمل cast للفلتر ويفشل برمي CastError، فالحذف كان بيفشل بصمت
      // ويرجع "internal_error" عام من غير ما يتحذف أي حاجة فعليًا، والمستخدم
      // يفضل شايف الكورس في الليستة ومحتار ليه "مش بيتحذف".
      //
      // هنا بنعمل fallback بالـ native driver (من غير أي كاست Mongoose)
      // عشان نضمن حذف المستند الفعلي أيًا كان شكل الـ _id بتاعه، وبرضه
      // ننضّف أي Sections/Lessons مرتبطة بيه لو موجودة.
      console.error("[/api/courses/[id]] DELETE fallback (raw driver) triggered:", deleteErr?.message);
      await Promise.all([
        Lesson.collection.deleteMany({ course: course._id }).catch(() => null),
        Section.collection.deleteMany({ course: course._id }).catch(() => null),
      ]);
      const rawResult = await Course.collection.deleteOne({ _id: course._id });
      if (!rawResult?.deletedCount) {
        console.error("[/api/courses/[id]] DELETE fallback failed to remove course:", course._id);
        return jsonResponse({ error: "delete_failed" }, 500);
      }
    }

    return jsonResponse({ success: true });
  } catch (err) {
    console.error("[/api/courses/[id]] DELETE error:", err);
    return jsonResponse({ error: "internal_error" }, 500);
  }
}