// path: app/(pages)/terms/page.jsx
"use client";

import { useState, useRef, useEffect } from "react";
import { useLanguage } from "@/contexts/LanguageContext";

/* ─────────────────────────────────────────
   SCROLL REVEAL HOOK
───────────────────────────────────────── */
function useReveal(threshold = 0.1) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    if (!ref.current) return;
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setVisible(true);
          obs.disconnect();
        }
      },
      { threshold }
    );
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return [ref, visible];
}

/* ═══════════════════════════════════════
   STATIC CONTENT — مأخوذ من مستند "Edumaster Terms & Conditions"
═══════════════════════════════════════ */
const CONTENT = {
  ar: {
    pageTitle: "الشروط والأحكام",
    lastUpdated: "آخر تحديث: سبتمبر 2026",
    companyInfo: {
      title: "بيانات المنصة",
      fields: [
        { label: "اسم المنصة", value: "Edumaster" },
        { label: "نوع الخدمة", value: "منصة تعليمية إلكترونية" },
        { label: "البريد الإلكتروني", value: "info@edumaster365.com" },
      ],
    },
    sections: [
      {
        id: "acceptance",
        title: "١. الموافقة على الشروط",
        text: "من خلال الوصول إلى المنصة أو استخدامها، فإنك توافق على هذه الشروط والأحكام وجميع السياسات ذات الصلة.",
      },
      {
        id: "services",
        title: "٢. وصف الخدمات",
        intro: "تقدم Edumaster:",
        items: [
          "الاستشارات الأكاديمية والمهنية",
          "دعم القبول الجامعي",
          "أدوات التقييم المهني المعتمدة على الذكاء الاصطناعي",
          "نظام إدارة الاستشارات (SaaS)",
          "خدمات استشارية للدراسة في الخارج",
        ],
        contact: "لا تضمن Edumaster القبول الجامعي أو المنح الدراسية أو التأشيرات أو الموافقة عليها.",
      },
      {
        id: "responsibilities",
        title: "٣. مسؤوليات المستخدم",
        intro: "يوافق المستخدمون على:",
        items: [
          "تقديم معلومات دقيقة وصحيحة",
          "تقديم مستندات أصلية وموثوقة",
          "استخدام المنصة بشكل قانوني",
          "احترام حقوق الملكية الفكرية",
        ],
      },
      {
        id: "payments",
        title: "٤. المدفوعات والرسوم",
        items: [
          "يتم الإفصاح عن الرسوم بوضوح قبل الدفع",
          "تتم معالجة المدفوعات عبر بوابات دفع آمنة",
          "يبدأ الوصول إلى الخدمات المدفوعة فور إتمام الدفع بنجاح",
        ],
      },
      {
        id: "ip",
        title: "٥. الملكية الفكرية",
        text: "جميع المحتويات والبرمجيات والخوارزميات والعلامات التجارية وميزات المنصة هي ملكية حصرية لشركة Edumaster Consulting. أي استخدام غير مصرّح به محظور تمامًا.",
      },
      {
        id: "liability",
        title: "٦. حدود المسؤولية",
        intro: "لا تتحمل Edumaster المسؤولية عن:",
        items: [
          "القرارات الصادرة عن الجامعات أو السفارات",
          "رفض طلبات التأشيرة",
          "التأخيرات الناتجة عن أطراف ثالثة",
          "النتائج المبنية على المعلومات المقدَّمة من المستخدم",
        ],
        contact: "تُقدَّم الخدمات \"كما هي\" و\"حسب توفرها\".",
      },
      {
        id: "termination",
        title: "٧. إنهاء الخدمة",
        text: "تحتفظ Edumaster بالحق في تعليق أو إنهاء الوصول إلى المنصة في حال إساءة الاستخدام أو الاحتيال أو مخالفة هذه الشروط.",
      },
      {
        id: "governing-law",
        title: "٨. القانون الحاكم",
        text: "تخضع هذه الشروط لقوانين جمهورية مصر العربية، ما لم تقتضِ اللوائح الدولية المعمول بها خلاف ذلك.",
      },
    ],
  },

  en: {
    pageTitle: "Terms & Conditions",
    lastUpdated: "Last updated: September 2026",
    companyInfo: {
      title: "Platform Information",
      fields: [
        { label: "Platform Name", value: "Edumaster" },
        { label: "Service Type", value: "Online Education Platform" },
        { label: "Email", value: "info@edumaster365.com" },
      ],
    },
    sections: [
      {
        id: "acceptance",
        title: "1. Acceptance",
        text: "By accessing or using the Platform, you agree to these Terms & Conditions and all related policies.",
      },
      {
        id: "services",
        title: "2. Services Description",
        intro: "Edumaster provides:",
        items: [
          "Academic and career counseling",
          "University admissions support",
          "AI-based career assessment tools",
          "SaaS counseling management system",
          "Study abroad advisory services",
        ],
        contact: "Edumaster does not guarantee admission, scholarships, visas, or visa approvals.",
      },
      {
        id: "responsibilities",
        title: "3. User Responsibilities",
        intro: "Users agree to:",
        items: [
          "Provide accurate and truthful information",
          "Submit authentic documents",
          "Use the Platform lawfully",
          "Respect intellectual property rights",
        ],
      },
      {
        id: "payments",
        title: "4. Payments & Fees",
        items: [
          "Fees are clearly communicated before payment",
          "Payments are processed via secure gateways",
          "Access to paid services begins upon successful payment",
        ],
      },
      {
        id: "ip",
        title: "5. Intellectual Property",
        text: "All content, software, algorithms, branding, and platform features are the exclusive property of Edumaster Consulting. Unauthorized use is strictly prohibited.",
      },
      {
        id: "liability",
        title: "6. Limitation of Liability",
        intro: "Edumaster is not liable for:",
        items: [
          "Decisions made by universities or embassies",
          "Visa rejections",
          "Delays caused by third parties",
          "Outcomes based on user-provided information",
        ],
        contact: "Services are provided \"as is\" and \"as available.\"",
      },
      {
        id: "termination",
        title: "7. Termination",
        text: "Edumaster reserves the right to suspend or terminate access in case of misuse, fraud, or violation of these terms.",
      },
      {
        id: "governing-law",
        title: "8. Governing Law",
        text: "These Terms are governed by the laws of the Arab Republic of Egypt, unless otherwise required by applicable international regulations.",
      },
    ],
  },

  es: {
    pageTitle: "Términos y Condiciones",
    lastUpdated: "Última actualización: septiembre de 2026",
    companyInfo: {
      title: "Información de la Plataforma",
      fields: [
        { label: "Nombre de la plataforma", value: "Edumaster" },
        { label: "Tipo de servicio", value: "Plataforma educativa en línea" },
        { label: "Correo electrónico", value: "info@edumaster365.com" },
      ],
    },
    sections: [
      {
        id: "acceptance",
        title: "1. Aceptación",
        text: "Al acceder o utilizar la Plataforma, aceptas estos Términos y Condiciones y todas las políticas relacionadas.",
      },
      {
        id: "services",
        title: "2. Descripción de los Servicios",
        intro: "Edumaster ofrece:",
        items: [
          "Asesoría académica y profesional",
          "Apoyo en la admisión universitaria",
          "Herramientas de evaluación profesional basadas en IA",
          "Sistema de gestión de asesoría (SaaS)",
          "Servicios de asesoría para estudiar en el extranjero",
        ],
        contact: "Edumaster no garantiza la admisión, becas, visados ni su aprobación.",
      },
      {
        id: "responsibilities",
        title: "3. Responsabilidades del Usuario",
        intro: "Los usuarios se comprometen a:",
        items: [
          "Proporcionar información precisa y veraz",
          "Presentar documentos auténticos",
          "Usar la Plataforma de forma lícita",
          "Respetar los derechos de propiedad intelectual",
        ],
      },
      {
        id: "payments",
        title: "4. Pagos y Tarifas",
        items: [
          "Las tarifas se comunican claramente antes del pago",
          "Los pagos se procesan a través de pasarelas seguras",
          "El acceso a los servicios pagos comienza tras un pago exitoso",
        ],
      },
      {
        id: "ip",
        title: "5. Propiedad Intelectual",
        text: "Todo el contenido, software, algoritmos, marca y funciones de la plataforma son propiedad exclusiva de Edumaster Consulting. El uso no autorizado está estrictamente prohibido.",
      },
      {
        id: "liability",
        title: "6. Limitación de Responsabilidad",
        intro: "Edumaster no se hace responsable de:",
        items: [
          "Decisiones tomadas por universidades o embajadas",
          "Rechazos de visado",
          "Retrasos causados por terceros",
          "Resultados basados en información proporcionada por el usuario",
        ],
        contact: "Los servicios se prestan \"tal cual\" y \"según disponibilidad\".",
      },
      {
        id: "termination",
        title: "7. Terminación",
        text: "Edumaster se reserva el derecho de suspender o cancelar el acceso en caso de mal uso, fraude o incumplimiento de estos términos.",
      },
      {
        id: "governing-law",
        title: "8. Ley Aplicable",
        text: "Estos Términos se rigen por las leyes de la República Árabe de Egipto, salvo que la normativa internacional aplicable exija lo contrario.",
      },
    ],
  },
};

/* ═══════════════════════════════════════
   ROOT PAGE
═══════════════════════════════════════ */
export default function TermsPage() {
  const { language: lang } = useLanguage();
  const t = CONTENT[lang] ?? CONTENT.en;
  const isRTL = lang === "ar";

  return (
    <>
      <style>{STYLES}</style>
      <div
        dir={isRTL ? "rtl" : "ltr"}
        className="min-h-screen bg-white text-[#0a0a0a] overflow-x-hidden"
      >
        <PageHeader t={t} />
        <CompanyInfo t={t} />
        <Sections t={t} />
      </div>
    </>
  );
}

/* ═══════════════════════════════════════
   PAGE HEADER
═══════════════════════════════════════ */
function PageHeader({ t }) {
  return (
    <section className="relative overflow-hidden bg-[#1E3561]">
      <div className="w-full px-5 sm:px-10 md:px-16 py-12 sm:py-20 md:py-28">
        <h1 className="font-semibold tracking-tight mb-3 sm:mb-4 leading-[1.1] text-white animate-fadein-up text-2xl sm:text-4xl md:text-5xl">
          {t.pageTitle}
        </h1>
        <p className="text-gray-300 text-sm sm:text-base animate-fadein-up2">
          {t.lastUpdated}
        </p>
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════
   COMPANY INFO
═══════════════════════════════════════ */
function CompanyInfo({ t }) {
  const [ref, visible] = useReveal();

  return (
    <section ref={ref} className="py-10 sm:py-16 md:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-5 sm:px-10 md:px-16">
        <h2
          className={`text-xl sm:text-2xl md:text-3xl font-semibold tracking-tight leading-tight mb-5 sm:mb-8 transition-all duration-700 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
        >
          {t.companyInfo.title}
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-px bg-gray-100 rounded-2xl overflow-hidden border border-gray-100">
          {t.companyInfo.fields.map((field, i) => (
            <div
              key={i}
              className={`bg-white p-4 sm:p-6 flex flex-col gap-1 transition-all duration-500 ${
                visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
              }`}
              style={{ transitionDelay: `${i * 70}ms` }}
            >
              <span className="text-gray-400 text-[10px] sm:text-xs font-bold uppercase tracking-widest">
                {field.label}
              </span>
              <span className="text-[#0a0a0a] font-semibold text-sm sm:text-base break-words">
                {field.value}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════
   SECTIONS
═══════════════════════════════════════ */
function Sections({ t }) {
  return (
    <section className="py-10 sm:py-16 md:py-20 bg-[#f7f7f7]">
      <div className="max-w-7xl mx-auto px-5 sm:px-10 md:px-16 flex flex-col gap-10 sm:gap-16">
        {t.sections.map((section) => (
          <SectionBlock key={section.id} section={section} />
        ))}
      </div>
    </section>
  );
}

function SectionBlock({ section }) {
  const [ref, visible] = useReveal();

  return (
    <div
      ref={ref}
      className={`bg-white rounded-2xl border border-gray-100 p-5 sm:p-8 md:p-10 transition-all duration-700 ${
        visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
      }`}
    >
      <h3 className="text-lg sm:text-xl md:text-2xl font-semibold tracking-tight leading-tight mb-3 sm:mb-5">
        {section.title}
      </h3>

      {section.intro && (
        <p className="text-gray-600 text-sm sm:text-[15px] leading-relaxed mb-4">
          {section.intro}
        </p>
      )}

      {section.text && (
        <p className="text-gray-600 text-sm sm:text-[15px] leading-relaxed mb-2">
          {section.text}
        </p>
      )}

      {section.contact && (
        <p className="font-bold text-[#C9A227] text-sm sm:text-[15px]">
          {section.contact}
        </p>
      )}

      {section.items && (
        <ul className="flex flex-col divide-y divide-gray-100 mt-2">
          {section.items.map((item, i) => (
            <li key={i} className="flex items-start gap-3 py-3 sm:py-3.5">
              <span className="shrink-0 w-5 h-5 sm:w-6 sm:h-6 flex items-center justify-center mt-0.5">
                <Check size={18} color="#C9A227" />
              </span>
              <span className="text-gray-700 font-medium text-sm sm:text-[15px] leading-snug">
                {item}
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════
   INLINE SVG ICON
═══════════════════════════════════════ */
function Check({ size = 16, color = "currentColor" }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke={color}
      strokeWidth={2.5}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 6L9 17l-5-5" />
    </svg>
  );
}

/* ═══════════════════════════════════════
   GLOBAL STYLES
═══════════════════════════════════════ */
const STYLES = `
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,700;0,9..40,900&family=Tajawal:wght@300;400;700;800&display=swap');

  @keyframes fadein-up {
    from { opacity: 0; transform: translateY(28px); }
    to   { opacity: 1; transform: translateY(0); }
  }

  .animate-fadein-up   { animation: fadein-up 0.7s ease 0.1s both; }
  .animate-fadein-up2  { animation: fadein-up 0.7s ease 0.25s both; }

  * { box-sizing: border-box; }
  img { max-width: 100%; }
`;