"use client";

// app/teacher/courses/[id]/assignments/page.jsx
//
// Phase 4 — اليوم 37-38: صفحة إدارة واجبات كورس معيّن.

import { useEffect, useState, use as usePromise } from "react";
import Link from "next/link";
import { ArrowRight, ArrowLeft, Plus, Pencil, Trash2, Inbox, Loader, Calendar } from "lucide-react";
import AssignmentFormModal from "@/app/teacher/components/AssignmentFormModal";
import CourseTabs from "@/app/teacher/components/CourseTabs";
import { useLanguage } from "@/contexts/LanguageContext";

const STRINGS = {
  ar: {
    noDueDate: "بدون موعد نهائي",
    loadError: "تعذّر تحميل الواجبات",
    confirmDelete: (title) => `حذف واجب "${title}"؟ هيتمسح معاه كل تسليمات الطلاب. متأكد؟`,
    deleteError: "حصل خطأ أثناء الحذف",
    backToContent: "رجوع لمحتوى الكورس",
    pageTitle: "الواجبات",
    newAssignment: "واجب جديد",
    empty: "لسه مفيش واجبات لهذا الكورس",
    published: "منشور",
    draft: "مسودة",
    fullScore: "الدرجة الكاملة",
    submissions: "التسليمات",
  },
  en: {
    noDueDate: "No due date",
    loadError: "Couldn't load assignments",
    confirmDelete: (title) => `Delete assignment "${title}"? All student submissions will be deleted with it. Are you sure?`,
    deleteError: "Something went wrong while deleting",
    backToContent: "Back to course content",
    pageTitle: "Assignments",
    newAssignment: "New assignment",
    empty: "No assignments for this course yet",
    published: "Published",
    draft: "Draft",
    fullScore: "Full score",
    submissions: "Submissions",
  },
};

export default function CourseAssignmentsPage({ params }) {
  const { id } = usePromise(params);
  const { language, isRTL } = useLanguage();
  const t = STRINGS[language] || STRINGS.en;
  const BackArrow = isRTL ? ArrowRight : ArrowLeft;
  const locale = language === "ar" ? "ar-EG" : language === "es" ? "es-ES" : "en-US";

  function formatDate(d) {
    if (!d) return t.noDueDate;
    return new Date(d).toLocaleString(locale, { dateStyle: "medium", timeStyle: "short" });
  }
  const [assignments, setAssignments] = useState(null);
  const [error, setError] = useState("");
  const [modal, setModal] = useState(undefined);

  async function load() {
    try {
      const res = await fetch(`/api/assignments?course=${id}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error);
      setAssignments(data.assignments);
    } catch {
      setError(t.loadError);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  function handleSaved(saved) {
    setModal(undefined);
    setAssignments((prev) => {
      if (!prev) return [saved];
      const exists = prev.some((a) => a.id === saved.id);
      return exists ? prev.map((a) => (a.id === saved.id ? saved : a)) : [...prev, saved];
    });
  }

  async function handleDelete(assignment) {
    if (!confirm(t.confirmDelete(assignment.title))) return;
    const res = await fetch(`/api/assignments/${assignment.id}`, { method: "DELETE" });
    if (res.ok) {
      setAssignments((prev) => prev.filter((a) => a.id !== assignment.id));
    } else {
      alert(t.deleteError);
    }
  }

  return (
    <div dir={isRTL ? "rtl" : "ltr"} className="max-w-4xl mx-auto px-4 sm:px-6 py-10">
      <Link href={`/teacher/courses/${id}`} className="inline-flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-800 mb-6">
        <BackArrow size={15} /> {t.backToContent}
      </Link>

      <CourseTabs courseId={id} active="assignments" />

      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-semibold text-gray-800">{t.pageTitle}</h1>
        <button
          onClick={() => setModal(null)}
          className="flex items-center gap-2 text-sm font-semibold bg-[#003A91] text-white px-4 py-2.5 rounded-xl hover:bg-[#002E74]"
        >
          <Plus size={16} /> {t.newAssignment}
        </button>
      </div>

      {error && <div className="bg-red-50 text-red-600 text-sm px-4 py-2.5 rounded-lg mb-4">{error}</div>}

      {!assignments ? (
        <div className="flex justify-center py-16">
          <Loader className="animate-spin text-[#2456A1]" size={32} />
        </div>
      ) : assignments.length === 0 ? (
        <div className="bg-white border-2 border-dashed border-gray-200 rounded-2xl py-14 text-center text-gray-400">
          {t.empty}
        </div>
      ) : (
        <div className="space-y-3">
          {assignments.map((a) => (
            <div key={a.id} className="bg-white rounded-2xl border border-gray-200 p-4 flex items-center gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-gray-800 truncate">{a.title}</h3>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${
                      a.isPublished ? "bg-green-50 text-green-600" : "bg-gray-100 text-gray-500"
                    }`}
                  >
                    {a.isPublished ? t.published : t.draft}
                  </span>
                </div>
                <p className="text-xs text-gray-400 flex items-center gap-1.5">
                  <Calendar size={12} /> {formatDate(a.dueDate)} · {t.fullScore} {a.maxScore}
                </p>
              </div>
              <Link
                href={`/teacher/assignments/${a.id}/submissions`}
                className="flex items-center gap-1.5 text-xs font-semibold bg-[#EBEFF6] text-[#003A91] px-3 py-2 rounded-lg hover:bg-[#D7E0EE] shrink-0"
              >
                <Inbox size={14} /> {t.submissions}
              </Link>
              <button onClick={() => setModal(a)} className="text-gray-400 hover:text-gray-700 p-2 shrink-0">
                <Pencil size={15} />
              </button>
              <button onClick={() => handleDelete(a)} className="text-red-400 hover:text-red-600 p-2 shrink-0">
                <Trash2 size={15} />
              </button>
            </div>
          ))}
        </div>
      )}

      {modal !== undefined && (
        <AssignmentFormModal courseId={id} assignment={modal} onClose={() => setModal(undefined)} onSaved={handleSaved} />
      )}
    </div>
  );
}