// app/api/categories/route.js
//
// GET: عام بالكامل (أي زائر يشوف التصنيفات — محتاجينها لفلترة الكورسات في
// الصفحة العامة). POST: أدمن بس.

import mongoose from "mongoose";
import { connectToMongo } from "@/app/lib/mongodb";
import { getCategoryModel } from "@/app/lib/models/Category";
import { requireRole } from "@/app/lib/rbac";
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/lib/authOptions";

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  });
}

function slugify(text) {
  return String(text)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9\u0600-\u06FF\s-]/g, "") // يسمح بحروف عربية كمان
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

const SUPPORTED_LANGS = ["ar", "en", "es"];

function sanitizeCategoryI18n(input) {
  const clean = {};
  if (!input || typeof input !== "object") return clean;
  for (const lang of SUPPORTED_LANGS) {
    const raw = input[lang];
    if (!raw || typeof raw !== "object") continue;
    clean[lang] = {
      name: String(raw.name || "").trim(),
      description: String(raw.description || ""),
    };
  }
  return clean;
}

export async function GET(request) {
  try {
    await connectToMongo();
    const Category = getCategoryModel();

    // ?all=1: لوحة الأدمن محتاجة تشوف التصنيفات المعطّلة كمان (عشان تقدر
    // تفعّلها تاني أو تعدّلها) — بنسمح بيها بس لو المستخدم أدمن فعلاً،
    // وإلا بيترجع نفس السلوك العام القديم (الفعّالة بس).
    const { searchParams } = new URL(request.url);
    const wantsAll = searchParams.get("all") === "1";
    // 🆕 ?parent=<id> بيرجّع بس الساب-تصنيفات التابعة لتصنيف معيّن (مفيد
    // للفرونت إند عشان يبني فلتر الساب-تصنيف بتاع أي تصنيف رئيسي عنده
    // ساب-تصنيفات، مش بس "Language"). ?parent=none|null|top بيرجّع بس
    // التصنيفات الرئيسية (parent=null).
    const parentParam = searchParams.get("parent");

    let filter = { isActive: true };
    if (wantsAll) {
      const session = await getServerSession(authOptions);
      if (session?.user?.role === "admin") {
        filter = {};
      }
    }
    if (parentParam) {
      if (["none", "null", "top"].includes(parentParam)) {
        filter.parent = null;
      } else if (mongoose.Types.ObjectId.isValid(parentParam)) {
        filter.parent = parentParam;
      }
    }

    const categories = await Category.find(filter)
      .sort({ order: 1, name: 1 })
      .lean();

    return jsonResponse(
      categories.map((c) => ({
        id: c._id.toString(),
        name: c.name,
        slug: c.slug,
        description: c.description,
        i18n: c.i18n instanceof Map ? Object.fromEntries(c.i18n) : c.i18n || {},
        icon: c.icon,
        order: c.order,
        isActive: c.isActive,
        parent: c.parent ? c.parent.toString() : null,
      }))
    );
  } catch (err) {
    console.error("[/api/categories] GET error:", err);
    return jsonResponse({ error: "internal_error" }, 500);
  }
}

export async function POST(request) {
  try {
    const auth = await requireRole(["admin"]);
    if (auth.response) return auth.response;

    const body = await request.json().catch(() => null);
    const name = String(body?.name || "").trim();
    if (!name) return jsonResponse({ error: "missing_name" }, 400);

    const slug = body?.slug ? slugify(body.slug) : slugify(name);
    if (!slug) return jsonResponse({ error: "invalid_slug" }, 400);

    await connectToMongo();
    const Category = getCategoryModel();

    const existing = await Category.findOne({ slug }).lean();
    if (existing) return jsonResponse({ error: "slug_taken" }, 409);

    // 🆕 ساب-تصنيف: لو body.parent موجود، لازم يكون id صالح لتصنيف موجود
    // فعلاً، وده التصنيف لازم يكون هو نفسه رئيسي (parent=null) — بنسمح
    // بمستوى واحد بس (رئيسي ← ساب) عشان نتجنب تعقيد شجرة متداخلة مالهاش
    // داعي حاليًا.
    let parent = null;
    if (body?.parent) {
      if (!mongoose.Types.ObjectId.isValid(body.parent)) {
        return jsonResponse({ error: "invalid_parent" }, 400);
      }
      const parentCat = await Category.findById(body.parent).lean();
      if (!parentCat) return jsonResponse({ error: "parent_not_found" }, 404);
      if (parentCat.parent) return jsonResponse({ error: "parent_must_be_top_level" }, 400);
      parent = body.parent;
    }

    const created = await Category.create({
      name,
      slug,
      description: String(body?.description || ""),
      icon: body?.icon || null,
      order: Number.isFinite(body?.order) ? body.order : 0,
      i18n: sanitizeCategoryI18n(body?.i18n),
      parent,
    });

    return jsonResponse(
      { id: created._id.toString(), name: created.name, slug: created.slug, parent: created.parent ? created.parent.toString() : null },
      201
    );
  } catch (err) {
    console.error("[/api/categories] POST error:", err);
    return jsonResponse({ error: "internal_error" }, 500);
  }
}