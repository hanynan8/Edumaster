"use client";

// app/teacher/components/CourseFormModal.jsx
//
// فورم إنشاء/تعديل دورة. بيستخدم POST /api/courses للإنشاء و
// PUT /api/courses/[id] للتعديل. الغلاف (thumbnail) بيترفع بـ MediaUploader
// (كـ "image") عن طريق /api/upload/file لـ Bunny Storage.
//
// 🩹 FIX: كل نصوص الفورم كانت متبوعة لـ object ترجمة (T) بس الـ JSX كان
// لسه بيستخدم نص عربي ثابت جوه الأكواد مباشرة (مش t.xxx) — يعني تغيير
// اللغة من الناف بار مكانش بيغيّر حاجة في الفورم دي بالذات. اتصلحت هنا:
// كل نص في الـ JSX بقى بياخد من t.* اللي بيتبع useLanguage().
//
// 🆕 كمان الفورم دلوقتي بتاخد محتوى الدورة (العنوان/الوصف/المتطلبات/
// هيتعلم إيه/الشهادة) بالتلات لغات المدعومة (ar/en/es) بدل نسخة واحدة —
// عن طريق تابات لغة جوه الفورم — وبتبعتها في body.i18n لـ API اللي أصلاً
// بيدعم الحفظ ده (شوف app/lib/models/Course.js و app/lib/courseHelpers.js
// sanitizeCourseI18n). النسخة العربية بتتخزن كمان في الحقول الأساسية
// (title/shortDescription/description/requirements/outcomes) كـ "نسخة
// افتراضية" للتوافق مع أي كود قديم لسه بيقرا course.title مباشرة وللبحث
// النصي ($text index). الدورة بيتعرض للطالب حسب لغة الموقع تلقائيًا (شوف
// app/(pages)/courses/page.jsx و app/(pages)/courses/[id]/page.jsx —
// بيختاروا course.i18n[language] مع fallback لـ en وبعدين للحقول الأساسية).
//
// 🆕 لو اللي فاتح الفورم "موديريتور": بيظهر حقل إجباري "المدرّس المشرف" —
// قايمة بإيميلات المدرّسين المسجلين (من GET /api/moderator/teachers) والكورس
// بيتسجل باسم المدرّس اللي بيختاره. باقي الأدوار مفيش عندهم الحقل ده.

import { useEffect, useRef, useState } from "react";
import { useSession } from "next-auth/react";
import { X, Loader, Check, RotateCcw } from "lucide-react";
import MediaUploader from "./MediaUploader";
import StudentGrantPicker from "./StudentGrantPicker";
import { useLanguage } from "@/contexts/LanguageContext";
import { SUPPORTED_CURRENCIES, convertPrice } from "@/app/lib/currency";

const LANGS = ["ar", "en", "es"];

// 🆕 مسودة "دورة جديد" في localStorage: لو المدرس قفل المودال بالغلط
// (زرار X، ضغط برّه المودال، أو حتى قفل التاب) قبل ما يضغط "إنشاء الدورة"،
// البيانات اللي كتبها (كل اللغات + التصنيف/المستوى/السعر...) تفضل محفوظة
// محليًا وترجع تلقائي أول ما يفتح فورم "دورة جديد" تاني. بتتمسح بس لما
// الدورة يتحفظ فعليًا بنجاح (POST ناجح) — مش لما يقفل المودال عادي، عشان
// كده بالظبط هي موجودة أصلاً. الفيتشر ده بيشتغل بس للدورة الجديد (مش
// التعديل) لأن دورة بيتعدّل أصلاً بياناته محفوظة في الداتابيز مش محتاجة
// حفظ مؤقت. المودال يقدر يتفتح لأكتر من مدرس على نفس الجهاز نظريًا، فمفتاح
// التخزين ثابت لكل الأجهزة (مفيش مقارنة بيانات مستخدم حساسة هنا أصلاً).
const NEW_COURSE_DRAFT_KEY = "edumaster:newCourseDraft:v1";

function loadNewCourseDraft() {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(NEW_COURSE_DRAFT_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object") return null;
    return parsed;
  } catch {
    return null;
  }
}

function saveNewCourseDraft(draft) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(NEW_COURSE_DRAFT_KEY, JSON.stringify({ ...draft, savedAt: Date.now() }));
  } catch {
    // لو الـ localStorage ممتلئ أو متعطّل (وضع تصفح خاص مثلًا)، تجاهل بصمت —
    // الفورم يفضل شغّال عادي من غير حفظ مؤقت بس.
  }
}

function clearNewCourseDraft() {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.removeItem(NEW_COURSE_DRAFT_KEY);
  } catch {
    // تجاهل
  }
}

// عشان نعرف لو المسودة المحفوظة فيها فعلًا حاجة اتكتبت (مش بس فورم فاضي
// اتحفظ بالغلط) قبل ما نعرض تنبيه "تم استرجاع مسودة".
function draftHasContent(draft) {
  if (!draft) return false;
  const anyTitle = LANGS.some((l) => draft.langContent?.[l]?.title?.trim());
  return Boolean(anyTitle || draft.form?.category || draft.form?.thumbnail);
}

const T = {
  en: {
    levels: { beginner: "Beginner", intermediate: "Intermediate", advanced: "Advanced" },
    statuses: {
      draft: "Draft",
      published: "Published (live for students)",
      pending: "Submit course & wait for admin approval",
      archived: "Archive only (hidden)",
    },
    submitForApproval: "Submit for admin approval",
    archiveOnly: "Archive only",
    titleRequired: "Title is required",
    titleRequiredAllLangs: "Please add a course title in all 3 languages (Arabic, English, Spanish)",
    chooseCategory: "Choose a category",
    submittedForReview: "The course was sent to the admin for review. It will appear to students once approved.",
    savedAsDraft:
      "The course was saved as a draft when created. To send it to the admin for review, open the course, add content (sections & lessons), then choose \"Publish\" again.",
    slugTaken: "This title is already used, try a different one",
    genericError: "Something went wrong, try again",
    editCourse: "Edit course",
    newCourse: "New course",
    multilingualHint: "This content is shown to students based on the site's current language. Fill in all three languages so the course displays correctly everywhere.",
    langTabs: { ar: "Arabic", en: "English", es: "Spanish" },
    courseTitle: "Course title *",
    shortDesc: "Short description (shown on the card)",
    fullDesc: "Full description",
    coverImage: "Cover image",
    category: "Category *",
    choose: "Choose...",
    subcategory: "Sub-category *",
    chooseSubcategory: "Choose a sub-category",
    level: "Level",
    priceLabel: "Price (per currency)",
    priceAutoHint: "Enter one currency and the other two are calculated automatically (approximate rate — you can still edit them).",
    free: "Free",
    egp: "EGP",
    usd: "USD (Dollar)",
    eur: "EUR (Euro)",
    requirements: "Prerequisites (one per line)",
    outcomes: "What students will learn (one per line)",
    certName: "Certificate name (optional)",
    certDesc: "Certificate description (optional)",
    tags: "Tags (comma-separated)",
    status: "Status",
    supervisingTeacher: "Supervising teacher *",
    supervisingTeacherHint: "The course is created under this teacher, who will see and manage it in their dashboard. Choose from the registered teachers' emails.",
    chooseTeacher: "Choose a teacher by email...",
    chooseTeacherRequired: "Choose the supervising teacher for this course",
    teachersLoading: "Loading teachers...",
    teachersLoadError: "Couldn't load the teachers list, try again",
    noTeachers: "No registered teachers yet",
    teacherInvalid: "The selected teacher is not valid, choose another one",
    grantLabel: "Enroll students for free (optional)",
    grantHint: "Pick registered students by email. They are enrolled in this course as if they had bought it — it opens for them automatically once the admin approves the course, with no need to sign up.",
    grantUnknownEmails: (list) => `These emails are not registered on the platform: ${list}`,
    grantInvalidEmails: (list) => `These emails are not valid: ${list}`,
    grantTooMany: "Too many students in one request, add them in smaller batches",
    grantDone: (n) => `${n} student(s) were enrolled for free.`,
    grantFailed: "The course was saved but enrolling the selected students failed — open the course edit form and add them again.",
    classMarkerQuizId: "ClassMarker Test ID (optional)",
    classMarkerQuizIdHint: "Paste the Quiz ID from your ClassMarker test link (e.g. the part after ?quiz= in https://www.classmarker.com/online-test/start?quiz=...). If filled in, a \"Test your level\" section will show on the course page. Leave empty for no test.",
    saveChanges: "Save changes",
    createCourse: "Create course",
    cancel: "Cancel",
    draftRestored: "We restored your unsaved draft from last time.",
    discardDraft: "Discard draft & start over",
  },
  ar: {
    levels: { beginner: "مبتدئ", intermediate: "متوسط", advanced: "متقدم" },
    statuses: {
      draft: "مسودة",
      published: "منشور (ظاهر للطلاب)",
      pending: "رفع الكورس وانتظار موافقة الإدارة",
      archived: "أرشفة الكورس فقط (مخفي)",
    },
    submitForApproval: "رفع الكورس وانتظار موافقة الأدمن",
    archiveOnly: "أرشفة فقط",
    titleRequired: "العنوان مطلوب",
    titleRequiredAllLangs: "من فضلك اكتب عنوان الدورة باللغات الثلاث (العربية والإنجليزية والإسبانية)",
    chooseCategory: "اختر تصنيفًا",
    submittedForReview: "تم إرسال الدورة إلى الإدارة للمراجعة. ستظهر للطلاب بعد موافقتها عليها.",
    savedAsDraft:
      "تم حفظ الدورة كمسودة عند إنشائها. لإرسالها إلى الإدارة للمراجعة، افتح الدورة وأضف المحتوى (الأقسام والدروس)، ثم اختر «نشر» مرة أخرى.",
    slugTaken: "العنوان مستخدم بالفعل، جرّب عنوانًا مختلفًا",
    genericError: "حدث خطأ، حاول مرة أخرى",
    editCourse: "تعديل الدورة",
    newCourse: "دورة جديد",
    multilingualHint: "يُعرض هذا المحتوى للطالب بحسب لغة الموقع الحالية. املأ اللغات الثلاث لتظهر الدورة بشكل صحيح لأي طالب أيًّا كانت لغته.",
    langTabs: { ar: "عربي", en: "إنجليزي", es: "إسباني" },
    courseTitle: "عنوان الدورة *",
    shortDesc: "وصف قصير (يظهر في البطاقة)",
    fullDesc: "الوصف الكامل",
    coverImage: "صورة الغلاف",
    category: "التصنيف *",
    choose: "اختر...",
    subcategory: "التصنيف الفرعي *",
    chooseSubcategory: "اختر التصنيف الفرعي",
    level: "المستوى",
    priceLabel: "السعر (لكل عملة)",
    priceAutoHint: "اكتب السعر بأي عملة وسيتم حساب العملتين الأخريين تلقائيًا (سعر تقريبي — يمكنك تعديلهما يدويًا بعد ذلك).",
    free: "مجاني",
    egp: "جنيه (EGP)",
    usd: "دولار (USD)",
    eur: "يورو (EUR)",
    requirements: "المتطلبات المسبقة (سطر لكل عنصر)",
    outcomes: "ما سيتعلمه الطالب (سطر لكل عنصر)",
    certName: "اسم الشهادة (اختياري)",
    certDesc: "وصف الشهادة (اختياري)",
    tags: "Tags (مفصولة بفاصلة)",
    status: "الحالة",
    supervisingTeacher: "المدرّس المشرف *",
    supervisingTeacherHint: "الكورس هيتسجل باسم المدرّس ده وهيظهر له في لوحته ويقدر يديره. اختر من إيميلات المدرّسين المسجلين.",
    chooseTeacher: "اختر المدرّس بالإيميل...",
    chooseTeacherRequired: "اختر المدرّس المشرف على هذا الكورس",
    teachersLoading: "جاري تحميل المدرّسين...",
    teachersLoadError: "تعذّر تحميل قائمة المدرّسين، حاول مرة أخرى",
    noTeachers: "لا يوجد مدرّسون مسجلون حتى الآن",
    teacherInvalid: "المدرّس المختار غير صالح، اختر مدرّسًا آخر",
    grantLabel: "تسجيل طلاب مجانًا (اختياري)",
    grantHint: "اختر طلابًا مسجّلين في المنصة بالإيميل. هيتسجّلوا في الكورس زي اللي اشتراه بالظبط — وهيتفتح عندهم تلقائيًا أول ما الأدمن يوافق على الكورس من غير ما يحتاجوا يشتركوا.",
    grantUnknownEmails: (list) => `الإيميلات دي غير مسجّلة في المنصة: ${list}`,
    grantInvalidEmails: (list) => `الإيميلات دي غير صالحة: ${list}`,
    grantTooMany: "عدد الطلاب كبير في طلب واحد، أضفهم على دفعات أصغر",
    grantDone: (n) => `تم تسجيل ${n} طالب مجانًا في الكورس.`,
    grantFailed: "تم حفظ الكورس لكن تعذّر تسجيل الطلاب المختارين — افتح تعديل الكورس وأضفهم مرة أخرى.",
    classMarkerQuizId: "معرّف اختبار ClassMarker (اختياري)",
    classMarkerQuizIdHint: "الصق معرّف الاختبار (Quiz ID) من رابط اختبار ClassMarker الخاص بك (الجزء الذي يلي ?quiz= في رابط مثل https://www.classmarker.com/online-test/start?quiz=...). إذا تم إدخاله، سيظهر قسم \"اختبر مستواك\" في صفحة الدورة. اتركه فارغًا إذا لم ترغب في اختبار.",
    saveChanges: "حفظ التعديلات",
    createCourse: "إنشاء الدورة",
    cancel: "إلغاء",
    draftRestored: "تمت استعادة البيانات التي كنت تكتبها سابقًا وهي لا تزال محفوظة.",
    discardDraft: "تجاهل المسودة والبدء من جديد",
  },
  es: {
    levels: { beginner: "Principiante", intermediate: "Intermedio", advanced: "Avanzado" },
    statuses: {
      draft: "Borrador",
      published: "Publicado (visible para estudiantes)",
      pending: "Enviar curso y esperar aprobación del admin",
      archived: "Solo archivar (oculto)",
    },
    submitForApproval: "Enviar para aprobación del admin",
    archiveOnly: "Solo archivar",
    titleRequired: "El título es obligatorio",
    titleRequiredAllLangs: "Agrega un título del curso en los 3 idiomas (árabe, inglés, español)",
    chooseCategory: "Elige una categoría",
    submittedForReview: "El curso se envió al administrador para su revisión. Aparecerá para los estudiantes una vez aprobado.",
    savedAsDraft:
      "El curso se guardó como borrador al crearse. Para enviarlo a revisión, abre el curso, agrega contenido (secciones y lecciones) y luego elige \"Publicar\" de nuevo.",
    slugTaken: "Este título ya está en uso, prueba con otro diferente",
    genericError: "Ocurrió un error, inténtalo de nuevo",
    editCourse: "Editar curso",
    newCourse: "Nuevo curso",
    multilingualHint: "Este contenido se muestra a los estudiantes según el idioma actual del sitio. Completa los tres idiomas para que el curso se muestre correctamente en todos lados.",
    langTabs: { ar: "Árabe", en: "Inglés", es: "Español" },
    courseTitle: "Título del curso *",
    shortDesc: "Descripción breve (se muestra en la tarjeta)",
    fullDesc: "Descripción completa",
    coverImage: "Imagen de portada",
    category: "Categoría *",
    choose: "Elige...",
    subcategory: "Subcategoría *",
    chooseSubcategory: "Elige una subcategoría",
    level: "Nivel",
    priceLabel: "Precio (por moneda)",
    priceAutoHint: "Introduce el precio en una moneda y las otras dos se calculan automáticamente (tasa aproximada — puedes editarlas después).",
    free: "Gratis",
    egp: "EGP (Libra egipcia)",
    usd: "USD (Dólar)",
    eur: "EUR (Euro)",
    requirements: "Requisitos previos (uno por línea)",
    outcomes: "Qué aprenderán (uno por línea)",
    certName: "Nombre del certificado (opcional)",
    certDesc: "Descripción del certificado (opcional)",
    tags: "Etiquetas (separadas por coma)",
    status: "Estado",
    supervisingTeacher: "Profesor supervisor *",
    supervisingTeacherHint: "El curso se crea a nombre de este profesor, quien lo verá y gestionará en su panel. Elige entre los correos de los profesores registrados.",
    chooseTeacher: "Elige un profesor por correo...",
    chooseTeacherRequired: "Elige el profesor supervisor de este curso",
    teachersLoading: "Cargando profesores...",
    teachersLoadError: "No se pudo cargar la lista de profesores, inténtalo de nuevo",
    noTeachers: "Aún no hay profesores registrados",
    teacherInvalid: "El profesor seleccionado no es válido, elige otro",
    grantLabel: "Inscribir estudiantes gratis (opcional)",
    grantHint: "Elige estudiantes registrados por correo. Quedan inscritos en este curso como si lo hubieran comprado: se les abre automáticamente cuando el administrador apruebe el curso, sin necesidad de inscribirse.",
    grantUnknownEmails: (list) => `Estos correos no están registrados en la plataforma: ${list}`,
    grantInvalidEmails: (list) => `Estos correos no son válidos: ${list}`,
    grantTooMany: "Demasiados estudiantes en una sola solicitud, añádelos en lotes más pequeños",
    grantDone: (n) => `${n} estudiante(s) inscritos gratis.`,
    grantFailed: "El curso se guardó pero falló la inscripción de los estudiantes seleccionados — abre la edición del curso y vuelve a añadirlos.",
    classMarkerQuizId: "ID de prueba ClassMarker (opcional)",
    classMarkerQuizIdHint: "Pega el Quiz ID del enlace de tu prueba ClassMarker (la parte después de ?quiz= en un enlace como https://www.classmarker.com/online-test/start?quiz=...). Si se completa, se mostrará una sección \"Evalúa tu nivel\" en la página del curso. Déjalo vacío si no quieres prueba.",
    saveChanges: "Guardar cambios",
    createCourse: "Crear curso",
    cancel: "Cancelar",
    draftRestored: "Restauramos tu borrador sin guardar de la última vez.",
    discardDraft: "Descartar borrador y empezar de nuevo",
  },
};

// بيبني محتوى لغة واحدة (تاب واحد) من i18n المخزن، مع fallback للحقول
// الأساسية القديمة (title/shortDescription/description/requirements/outcomes)
// لو مفيش نسخة i18n لسه للغة دي (دورة قديم اتعمل قبل الفيتشر ده مثلاً).
function langContentFrom(i18nLang, fallback) {
  return {
    title: i18nLang?.title ?? fallback?.title ?? "",
    shortDescription: i18nLang?.shortDescription ?? fallback?.shortDescription ?? "",
    description: i18nLang?.description ?? fallback?.description ?? "",
    requirements: (i18nLang?.requirements?.length ? i18nLang.requirements : fallback?.requirements || []).join("\n"),
    outcomes: (i18nLang?.outcomes?.length ? i18nLang.outcomes : fallback?.outcomes || []).join("\n"),
    certName: i18nLang?.certification?.name ?? fallback?.certName ?? "",
    certDesc: i18nLang?.certification?.desc ?? fallback?.certDesc ?? "",
  };
}

export default function CourseFormModal({ course, onClose, onSaved, moderatorMode = false }) {
  const { language } = useLanguage();
  const { data: session } = useSession();
  // 🆕 الأدمن جوه "موديريتور داشبورد" (moderatorMode) بيشوف نفس فورم الموديريتور
  // (اختيار المدرّس المشرف) — خارجها فورم الأدمن العادي.
  const isModerator =
    session?.user?.role === "moderator" ||
    (session?.user?.role === "admin" && moderatorMode);
  const t = T[language] || T.en;
  const LEVELS = [
    { value: "beginner", label: t.levels.beginner },
    { value: "intermediate", label: t.levels.intermediate },
    { value: "advanced", label: t.levels.advanced },
  ];
  // 🆕 المدرّس قدامه خيارين بس: (1) رفع الكورس وانتظار موافقة الأدمن، أو
  // (2) أرشفة الكورس فقط. لو الكورس منشور فعلاً، الخيار الأول بيبقى "منشور"
  // (من غير ما نرجّعه للمراجعة ونخفيه عن الطلاب) والتاني الأرشفة.
  const primaryStatus = course?.status === "published" ? "published" : "pending";
  const submitStatusRef = useRef(null);
  const isEdit = Boolean(course);
  const [categories, setCategories] = useState([]);
  // 🆕 قايمة المدرّسين (للموديريتور بس): null = لسه بيتحمّل، [] = فاضية.
  const [teachers, setTeachers] = useState(null);
  const [teachersError, setTeachersError] = useState(false);
  // 🆕 طلاب هيتسجّلوا مجانًا في الكورس (إيميلات). مقصود إنهم برّه مسودة
  // localStorage عشان إيميلات الطلاب ماتتخزّنش على الجهاز. alreadyGranted =
  // اللي اتسجّلوا قبل كده (وضع التعديل بس).
  const [grantedEmails, setGrantedEmails] = useState([]);
  const [alreadyGranted, setAlreadyGranted] = useState([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [activeTab, setActiveTab] = useState("ar");
  const [draftRestored, setDraftRestored] = useState(false);
  // ⚠️ لازم نستنى لحد ما نحاول نحمّل المسودة الأول قبل ما نبدأ نكتبها تاني،
  // وإلا هنكتب فورم فاضي فوق المسودة المحفوظة في اللحظة اللي المودال بيتفتح
  // فيها (useEffect بتاع الحفظ هيشتغل قبل useEffect بتاع التحميل لو مفيش
  // guard زي ده).
  const draftHydrated = useRef(isEdit); // مودال التعديل مش محتاج تحميل مسودة أصلًا

  // 🆕 محتوى منفصل لكل لغة (عنوان/وصف قصير/وصف كامل/متطلبات/هيتعلم إيه/شهادة)
  const [langContent, setLangContent] = useState(() => ({
    ar: langContentFrom(course?.i18n?.ar, {
      title: course?.title,
      shortDescription: course?.shortDescription,
      description: course?.description,
      requirements: course?.requirements,
      outcomes: course?.outcomes,
    }),
    en: langContentFrom(course?.i18n?.en, null),
    es: langContentFrom(course?.i18n?.es, null),
  }));

  const [form, setForm] = useState({
    thumbnail: course?.thumbnail || "",
    category: course?.category || "",
    subcategory: course?.subcategory || "",
    teacher: course?.teacher || "", // 🆕 المدرّس المشرف (بيتستخدم للموديريتور بس)
    level: course?.level || "beginner",
    language: course?.language || "ar",
    prices: {
      EGP: course?.prices?.EGP ?? 0,
      USD: course?.prices?.USD ?? 0,
      EUR: course?.prices?.EUR ?? 0,
    },
    isFree: course?.isFree ?? false,
    status: course?.status === "published" || course?.status === "archived" ? course.status : "pending",
    tags: (course?.tags || []).join(", "),
    classMarkerQuizId: course?.classMarkerQuizId || "",
  });

  useEffect(() => {
    fetch("/api/categories")
      .then((r) => r.json())
      .then(setCategories)
      .catch(() => setCategories([]));
  }, []);

  // 🆕 الموديريتور: تحميل قايمة المدرّسين المسجلين لاختيار المشرف بالإيميل.
  useEffect(() => {
    if (!isModerator) return;
    let cancelled = false;
    fetch("/api/moderator/teachers")
      .then(async (r) => {
        const data = await r.json();
        if (!r.ok) throw new Error(data?.error || "load_failed");
        return data;
      })
      .then((data) => {
        if (cancelled) return;
        setTeachers(data.teachers || []);
        setTeachersError(false);
      })
      .catch(() => {
        if (cancelled) return;
        setTeachers([]);
        setTeachersError(true);
      });
    return () => {
      cancelled = true;
    };
  }, [isModerator]);

  // 🆕 الموديريتور في وضع التعديل: نجيب الطلاب اللي اتسجّلوا مجانًا قبل كده.
  useEffect(() => {
    if (!isModerator || !isEdit) return;
    let cancelled = false;
    fetch(`/api/courses/${course.id}/grants`)
      .then((r) => (r.ok ? r.json() : { students: [] }))
      .then((data) => {
        if (!cancelled) setAlreadyGranted(Array.isArray(data?.students) ? data.students : []);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isModerator, isEdit]);

  // 🆕 تحميل مسودة "دورة جديد" المحفوظة (لو موجودة) أول ما المودال يتفتح —
  // بس في وضع "دورة جديد" (isEdit=false)، مرة واحدة بس عند الـ mount.
  useEffect(() => {
    if (isEdit) return; // مودال تعديل: مفيش مسودة تتحمّل
    const draft = loadNewCourseDraft();
    if (draft && draftHasContent(draft)) {
      if (draft.langContent) setLangContent((c) => ({ ...c, ...draft.langContent }));
      if (draft.form) {
        setForm((f) => ({
          ...f,
          ...draft.form,
          // مسودة قديمة ممكن تكون محفوظة بحالة "draft"/"published" — الخيارين
          // المسموحين دلوقتي pending أو archived بس.
          status: draft.form.status === "archived" ? "archived" : "pending",
        }));
      }
      setDraftRestored(true);
    }
    draftHydrated.current = true;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // 🆕 حفظ تلقائي في localStorage كل ما المدرس يعدّل أي حاجة في الفورم —
  // بس في وضع "دورة جديد"، وبعد ما نخلّص محاولة تحميل مسودة قديمة (guard
  // بـ draftHydrated فوق) عشان منمسحش مسودة موجودة بفورم فاضي للحظة.
  useEffect(() => {
    if (isEdit) return;
    if (!draftHydrated.current) return;
    saveNewCourseDraft({ langContent, form });
  }, [isEdit, langContent, form]);

  function discardDraft() {
    clearNewCourseDraft();
    setLangContent({
      ar: langContentFrom(null, null),
      en: langContentFrom(null, null),
      es: langContentFrom(null, null),
    });
    setForm({
      thumbnail: "",
      category: "",
      subcategory: "",
      teacher: "",
      level: "beginner",
      language: "ar",
      prices: { EGP: 0, USD: 0, EUR: 0 },
      isFree: false,
      status: "pending",
      tags: "",
      classMarkerQuizId: "",
    });
    setDraftRestored(false);
  }

  function update(field, value) {
    setForm((f) => {
      // 🆕 لو المدرس غيّر التصنيف الرئيسي، لازم نصفّر الساب-تصنيف المختار
      // (لو كان فيه) — وإلا ممكن يفضل مربوط بساب-تصنيف تابع لتصنيف رئيسي
      // تاني (مش موجود أصلًا تحت التصنيف الجديد).
      if (field === "category" && value !== f.category) {
        return { ...f, category: value, subcategory: "" };
      }
      return { ...f, [field]: value };
    });
  }

  // 🆕 لما المدرس يعدّل سعر عملة واحدة، بنحسب باقي العملتين تلقائيًا بسعر
  // صرف تقريبي (شوف EXCHANGE_RATES_TO_EGP في app/lib/currency.js) — بدل
  // ما يحتاج يكتب الأسعار التلاتة يدوي كل مرة. لسه يقدر يعدّل أي حقل يدوي
  // بعد كده؛ بس لو رجع يعدّل نفس الحقل اللي حسب منه تاني هيعيد الحساب.
  function updatePrice(currency, value) {
    setForm((f) => {
      const nextPrices = { ...f.prices, [currency]: value };
      const numericValue = Number(value);
      if (Number.isFinite(numericValue) && numericValue > 0) {
        for (const other of SUPPORTED_CURRENCIES) {
          if (other !== currency) {
            nextPrices[other] = convertPrice(numericValue, currency, other);
          }
        }
      }
      return { ...f, prices: nextPrices };
    });
  }

  // 🆕 التصنيف المختار حاليًا هو "Language" ولا لأ — بيتحدد بالـ slug (مش
  // الاسم) عشان يفضل شغال أيًا كانت لغة الموقع الحالية. لو الإدارة مغيّرش
  // اسم/slug التصنيف ده من لوحة التصنيفات، الفحص ده هيفضل شغال زي ما هو.
  const isLanguageCategory = categories.find((c) => c.id === form.category)?.slug === "language";

  // 🆕 نظام الساب-تصنيفات الحقيقي: التصنيف الرئيسي (dropdown الأول) بيعرض
  // بس التصنيفات اللي مالهاش parent (top-level) — الساب-تصنيفات (زي عربي/
  // إنجليزي/إسباني تحت "Language") بتتعرض في dropdown تاني منفصل بيظهر بس
  // لو التصنيف المختار فعلاً عنده ساب-تصنيفات حقيقية متخزنة في الداتابيز
  // (مش أي قايمة ثابتة في الكود). ده بيشتغل لأي تصنيف رئيسي عنده
  // ساب-تصنيفات، مش بس "Language".
  const topCategories = categories.filter((c) => !c.parent);
  const subcategories = categories.filter((c) => c.parent === form.category);
  const hasSubcategories = subcategories.length > 0;

  function updateLang(lang, field, value) {
    setLangContent((c) => ({ ...c, [lang]: { ...c[lang], [field]: value } }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    // الزرار اللي اتداس هو اللي بيحدد الحالة: "رفع/حفظ" (الافتراضي، وبيشتغل
    // كمان لو داس Enter) أو "أرشفة فقط".
    const chosenStatus = submitStatusRef.current || primaryStatus;
    submitStatusRef.current = null;
    setError("");

    const missingLang = LANGS.find((lang) => !langContent[lang].title.trim());
    if (missingLang) {
      setActiveTab(missingLang);
      return setError(t.titleRequiredAllLangs);
    }
    if (!form.category) return setError(t.chooseCategory);
    if (hasSubcategories && !form.subcategory) return setError(t.chooseSubcategory);
    if (isModerator && !form.teacher) return setError(t.chooseTeacherRequired);

    setSaving(true);
    try {
      const i18n = {};
      for (const lang of LANGS) {
        const c = langContent[lang];
        i18n[lang] = {
          title: c.title.trim(),
          shortDescription: c.shortDescription,
          description: c.description,
          requirements: c.requirements.split("\n").map((s) => s.trim()).filter(Boolean),
          outcomes: c.outcomes.split("\n").map((s) => s.trim()).filter(Boolean),
          certification: { name: c.certName || "", desc: c.certDesc || "" },
        };
      }
      // النسخة العربية هي "النسخة الافتراضية" برّه i18n (زي ما هو موضح في
      // تعليق app/lib/models/Course.js) — دايمًا موجودة لأننا بنتأكد إن
      // عنوان كل لغة (بما فيها العربي) مطلوب فوق.
      const base = i18n.ar;

      const payload = {
        title: base.title,
        shortDescription: base.shortDescription,
        description: base.description,
        thumbnail: form.thumbnail || null,
        category: form.category,
        // 🆕 ساب-تصنيف حقيقي (لو التصنيف المختار عنده ساب-تصنيفات) — بيتبعت
        // null لو التصنيف مالوش ساب-تصنيفات أصلًا.
        subcategory: hasSubcategories ? form.subcategory : null,
        level: form.level,
        language: form.language,
        i18n,
        prices: {
          EGP: Number(form.prices.EGP) || 0,
          USD: Number(form.prices.USD) || 0,
          EUR: Number(form.prices.EUR) || 0,
        },
        isFree: form.isFree,
        status: chosenStatus,
        requirements: base.requirements,
        outcomes: base.outcomes,
        tags: form.tags.split(",").map((s) => s.trim()).filter(Boolean),
        classMarkerQuizId: form.classMarkerQuizId.trim(),
      };
      // 🆕 الموديريتور بيبعت المدرّس المشرف: دايمًا في الإنشاء، وفي التعديل
      // بس لو غيّره فعلًا (عشان كورس مدرّسه الأصلي مش "teacher" — زي كورس
      // أدمن — ميترفضش بسبب إننا بعتنا نفس القيمة تاني).
      if (isModerator && (!isEdit || form.teacher !== course.teacher)) {
        payload.teacher = form.teacher;
      }
      // 🆕 الطلاب اللي هيتسجّلوا مجانًا (موديريتور/أدمن بس) — بيتبعتوا بس لو
      // اتختار حد، والسيرفر بيتحقق إنهم مسجّلين فعلًا في المنصة.
      if (isModerator && grantedEmails.length > 0) {
        payload.grantedEmails = grantedEmails;
      }

      const res = await fetch(isEdit ? `/api/courses/${course.id}` : "/api/courses", {
        method: isEdit ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        const failure = new Error(data?.error || "save_failed");
        failure.invalid = data?.invalid;
        throw failure;
      }

      // 🆕 لو المدرس اختار "نشر" بس الباك إند حوّل الحالة لـ "قيد المراجعة"
      // (شوف تعليق app/api/courses/[id]/route.js PUT)، لازم يعرف إن الدورة
      // مش هيظهر للطلاب دلوقتي — الفورم بيتقفل فورًا (onSaved) فمفيش وقت
      // نعرض رسالة جوه المودال نفسه، فبنستخدم alert زي باقي رسائل الحالة
      // المشابهة في الصفحة (شوف teacher/page.jsx handleDelete).
      if (data?.submittedForReview) {
        alert(t.submittedForReview);
      }

      // 🆕 نتيجة تسجيل الطلاب المجاني.
      if (data?.grantFailed) {
        alert(t.grantFailed);
      } else if (data?.grant?.granted > 0) {
        alert(t.grantDone(data.grant.granted));
      }

      // 🆕 الدورة اتحفظ فعليًا في الداتابيز، فمفيش داعي للمسودة المحلية تاني.
      if (!isEdit) clearNewCourseDraft();

      onSaved(data);
    } catch (err) {
      const teacherErrors = ["invalid_teacher", "teacher_not_found", "user_is_not_teacher", "teacher_suspended"];
      const emailList = Array.isArray(err.invalid) ? err.invalid.slice(0, 5).join(", ") + (err.invalid.length > 5 ? "…" : "") : "";
      setError(
        err.message === "slug_taken"
          ? t.slugTaken
          : teacherErrors.includes(err.message)
            ? t.teacherInvalid
            : err.message === "unknown_emails"
              ? t.grantUnknownEmails(emailList)
              : err.message === "invalid_emails"
                ? t.grantInvalidEmails(emailList)
                : err.message === "too_many_emails"
                  ? t.grantTooMany
                  : t.genericError
      );
    } finally {
      setSaving(false);
    }
  }

  const tab = langContent[activeTab];
  const isRTL = language === "ar";

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div
        className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
        dir={isRTL ? "rtl" : "ltr"}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b sticky top-0 bg-white rounded-t-2xl z-10">
          <h3 className="text-lg font-semibold text-gray-800">{isEdit ? t.editCourse : t.newCourse}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700">
            <X size={22} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && <div className="bg-red-50 text-red-600 text-sm px-4 py-2.5 rounded-lg">{error}</div>}

          {/* 🆕 بانر مسودة مستردة — بيظهر بس لو فيه مسودة "دورة جديد" اتحمّلت
              فعليًا من localStorage عند فتح المودال. */}
          {!isEdit && draftRestored && (
            <div className="flex items-center justify-between gap-3 bg-amber-50 border border-amber-200 text-amber-800 text-xs px-4 py-2.5 rounded-lg">
              <span>{t.draftRestored}</span>
              <button
                type="button"
                onClick={discardDraft}
                className="shrink-0 inline-flex items-center gap-1.5 font-semibold underline hover:no-underline"
              >
                <RotateCcw size={12} />
                {t.discardDraft}
              </button>
            </div>
          )}

          {/* 🆕 المدرّس المشرف — بيظهر للموديريتور بس. الكورس بيتسجل باسم
              المدرّس المختار (بالإيميل) وبيتبعت pending للأدمن زي أي كورس. */}
          {isModerator && (
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t.supervisingTeacher}</label>
              <select
                className="w-full border border-gray-300 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-[#5279B4]"
                value={form.teacher}
                onChange={(e) => update("teacher", e.target.value)}
                disabled={teachers === null}
                required
              >
                <option value="">{teachers === null ? t.teachersLoading : t.chooseTeacher}</option>
                {/* لو الكورس الحالي مدرّسه مش في القايمة (مثلاً كورس أدمن)،
                    بنعرضه كخيار عشان الاختيار الحالي ميظهرش فاضي. */}
                {isEdit &&
                  course?.teacher &&
                  teachers &&
                  !teachers.some((x) => x.id === course.teacher) && (
                    <option value={course.teacher}>{course.teacherName || course.teacher}</option>
                  )}
                {(teachers || []).map((x) => (
                  <option key={x.id} value={x.id}>
                    {x.email}
                    {x.name ? ` — ${x.name}` : ""}
                  </option>
                ))}
              </select>
              <p className="text-xs text-gray-400 mt-1.5">{t.supervisingTeacherHint}</p>
              {teachersError && <p className="text-xs text-red-500 mt-1">{t.teachersLoadError}</p>}
              {teachers && teachers.length === 0 && !teachersError && (
                <p className="text-xs text-amber-600 mt-1">{t.noTeachers}</p>
              )}
            </div>
          )}

          {/* 🆕 تسجيل طلاب مجانًا — موديريتور/أدمن بس. الطلاب بيتسجّلوا في الكورس
              فعليًا وقت الحفظ فيتفتح عندهم أول ما الأدمن يوافق على الكورس. */}
          {isModerator && (
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t.grantLabel}</label>
              <StudentGrantPicker
                selected={grantedEmails}
                onChange={setGrantedEmails}
                alreadyGranted={alreadyGranted}
                language={language}
              />
              <p className="text-xs text-gray-400 mt-1.5">{t.grantHint}</p>
            </div>
          )}

          <div className="bg-[#EBEFF6] text-[#002E74] text-xs px-4 py-2.5 rounded-lg">{t.multilingualHint}</div>

          {/* 🆕 تابات اللغة — كل تاب بيعبّي محتوى الدورة (عنوان/وصف/متطلبات/
              هيتعلم إيه/شهادة) للغة دي بالتحديد، بغض النظر عن لغة الناف بار
              الحالية (لغة الناف بار بتتحكم بس في نصوص الفورم نفسها). */}
          <div className="flex gap-1 bg-gray-100 p-1 rounded-xl">
            {LANGS.map((lang) => {
              const filled = Boolean(langContent[lang].title.trim());
              return (
                <button
                  key={lang}
                  type="button"
                  onClick={() => setActiveTab(lang)}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-sm font-semibold transition ${
                    activeTab === lang ? "bg-white shadow text-[#003A91]" : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  {filled && <Check size={14} className="text-green-500" />}
                  {t.langTabs[lang]}
                </button>
              );
            })}
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t.courseTitle}</label>
            <input
              className="w-full border border-gray-300 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-[#5279B4] focus:border-[#5279B4] outline-none"
              value={tab.title}
              onChange={(e) => updateLang(activeTab, "title", e.target.value)}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t.shortDesc}</label>
            <input
              maxLength={300}
              className="w-full border border-gray-300 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-[#5279B4] focus:border-[#5279B4] outline-none"
              value={tab.shortDescription}
              onChange={(e) => updateLang(activeTab, "shortDescription", e.target.value)}
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t.fullDesc}</label>
            <textarea
              rows={4}
              className="w-full border border-gray-300 rounded-xl px-4 py-2.5 focus:ring-2 focus:ring-[#5279B4] focus:border-[#5279B4] outline-none"
              value={tab.description}
              onChange={(e) => updateLang(activeTab, "description", e.target.value)}
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t.requirements}</label>
            <textarea
              rows={2}
              className="w-full border border-gray-300 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-[#5279B4]"
              value={tab.requirements}
              onChange={(e) => updateLang(activeTab, "requirements", e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t.outcomes}</label>
            <textarea
              rows={2}
              className="w-full border border-gray-300 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-[#5279B4]"
              value={tab.outcomes}
              onChange={(e) => updateLang(activeTab, "outcomes", e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t.certName}</label>
              <input
                className="w-full border border-gray-300 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-[#5279B4]"
                value={tab.certName}
                onChange={(e) => updateLang(activeTab, "certName", e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t.certDesc}</label>
              <input
                className="w-full border border-gray-300 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-[#5279B4]"
                value={tab.certDesc}
                onChange={(e) => updateLang(activeTab, "certDesc", e.target.value)}
              />
            </div>
          </div>

          <hr className="border-gray-200" />

          {/* بيانات مش لغوية (نفس القيمة لكل اللغات): الغلاف/التصنيف/المستوى/
              السعر/الحالة/الـ tags */}
          <MediaUploader
            kind="image"
            label={t.coverImage}
            currentUrl={form.thumbnail}
            onUploaded={(f) => update("thumbnail", f.url)}
          />

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t.category}</label>
              <select
                className="w-full border border-gray-300 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-[#5279B4]"
                value={form.category}
                onChange={(e) => update("category", e.target.value)}
                required
              >
                <option value="">{t.choose}</option>
                {topCategories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.i18n?.[language]?.name || c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t.level}</label>
              <select
                className="w-full border border-gray-300 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-[#5279B4]"
                value={form.level}
                onChange={(e) => update("level", e.target.value)}
              >
                {LEVELS.map((l) => (
                  <option key={l.value} value={l.value}>
                    {l.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* 🆕 ساب-تصنيف حقيقي — بيظهر بس لو التصنيف المختار فعلاً عنده
              ساب-تصنيفات متخزنة في الداتابيز (شوف hasSubcategories فوق).
              لتصنيف "Language" دي هي اللي بتحدد لغة الدورة فعليًا دلوقتي
              (بدل حقل ثابت مالوش واجهة زي الأول). */}
          {hasSubcategories && (
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t.subcategory}</label>
              <select
                className="w-full border border-gray-300 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-[#5279B4]"
                value={form.subcategory}
                onChange={(e) => update("subcategory", e.target.value)}
                required
              >
                <option value="">{t.choose}</option>
                {subcategories.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.i18n?.[language]?.name || s.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-sm font-semibold text-gray-700">{t.priceLabel}</label>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700">
                <input type="checkbox" checked={form.isFree} onChange={(e) => update("isFree", e.target.checked)} />
                {t.free}
              </label>
            </div>
            <p className="text-xs text-gray-400 mb-2">{t.priceAutoHint}</p>
            {/* 🆕 سعر منفصل يدوي لكل عملة (بدل تحويل تلقائي بسعر صرف) — العملة
                اللي المستخدم بيدفع بيها بتتحدد حسب لغة الموقع وقت الشراء
                (شوف app/lib/currency.js). لازم تتحط قيمة لكل العملات التلاتة
                عشان الدورة يبقى قابل للشراء بأي لغة. */}
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1">{t.egp}</label>
                <input
                  type="number"
                  min={0}
                  disabled={form.isFree}
                  className="w-full border border-gray-300 rounded-xl px-3 py-2.5 outline-none focus:ring-2 focus:ring-[#5279B4] disabled:bg-gray-100"
                  value={form.prices.EGP}
                  onChange={(e) => updatePrice("EGP", e.target.value)}
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1">{t.usd}</label>
                <input
                  type="number"
                  min={0}
                  disabled={form.isFree}
                  className="w-full border border-gray-300 rounded-xl px-3 py-2.5 outline-none focus:ring-2 focus:ring-[#5279B4] disabled:bg-gray-100"
                  value={form.prices.USD}
                  onChange={(e) => updatePrice("USD", e.target.value)}
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1">{t.eur}</label>
                <input
                  type="number"
                  min={0}
                  disabled={form.isFree}
                  className="w-full border border-gray-300 rounded-xl px-3 py-2.5 outline-none focus:ring-2 focus:ring-[#5279B4] disabled:bg-gray-100"
                  value={form.prices.EUR}
                  onChange={(e) => updatePrice("EUR", e.target.value)}
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t.tags}</label>
            <input
              className="w-full border border-gray-300 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-[#5279B4]"
              value={form.tags}
              onChange={(e) => update("tags", e.target.value)}
            />
          </div>

          {/* 🆕 اختبار "قيّم مستواك" (ClassMarker) — الحقل ده بيظهر بس لو
              التصنيف المختار هو "Language" (categorySlug === "language")،
              لأن الاختبار ده معناه بس لدورات اللغة (اختبار تحديد مستوى في
              لغة معيّنة). لو المدرس بدّل التصنيف لحاجة تانية، الحقل بيختفي
              (لكن القيمة المحفوظة مش بتتمسح من الداتابيز، بترجع تظهر تاني
              لو رجّع اختار Language تاني). */}
          {isLanguageCategory && (
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t.classMarkerQuizId}</label>
              <input
                className="w-full border border-gray-300 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-[#5279B4]"
                value={form.classMarkerQuizId}
                onChange={(e) => update("classMarkerQuizId", e.target.value)}
                placeholder="yba59c342adc8815"
              />
              <p className="text-xs text-gray-400 mt-1.5 leading-relaxed">{t.classMarkerQuizIdHint}</p>
            </div>
          )}

          <div className="space-y-3 pt-2">
            <button
              type="submit"
              disabled={saving}
              onClick={() => { submitStatusRef.current = primaryStatus; }}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-[#003A91] to-[#003A91] text-white font-bold py-3 rounded-xl hover:opacity-90 disabled:opacity-60"
            >
              {saving && <Loader size={18} className="animate-spin" />}
              {primaryStatus === "published" ? t.saveChanges : t.submitForApproval}
            </button>
            <div className="flex gap-3">
              <button
                type="submit"
                disabled={saving}
                onClick={() => { submitStatusRef.current = "archived"; }}
                className="flex-1 py-2.5 rounded-xl bg-gray-100 text-gray-500 text-sm font-medium hover:bg-gray-200 hover:text-gray-700 disabled:opacity-60"
              >
                {t.archiveOnly}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-2.5 rounded-xl border border-gray-200 text-gray-500 text-sm font-medium hover:bg-gray-50"
              >
                {t.cancel}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}